#setwd("C:/Users/User/Documents/CHMP/chmp_V04")

library(shiny)
library(shinydashboard)
library(glue)
library(shinyauthr)
library(RSQLite)
library(DBI)
library(lubridate)
require(plotly)
library(dplyr)
#library(flexdashboard)
library(ggplot2)
library(readxl)
library(tidyverse)
library(ggmap)
library(knitr)
require(ECharts2Shiny)
library(ggiraph)
library(highcharter)
library(ggpubr)
library(reshape2)
library(hrbrthemes)
library(c3)
library(zoo)
library(DT)  
library(magrittr)
library(formattable)

user_base <- tibble(
  user = c("Tom Abonyo",
           
           "Margaret  Njoroge",
           
           "Nelly Kimani",
           
           "Bessy Ayieko",
           
           "George Ngugi",
           
           "Alex Mathara",
           
           "Timothy Theuri",
           
           "Parmindar Lotay",
           
           "Bertrand Chenin",
           
           "Olivier Andriollo",
           
           "Olivier De Santi",
           
           "Paul Lotay",
           
           "Guest"),
  password = sapply(c("Chmp@nb!"), sodium::password_store), 
  permissions = c("admin", "standard", "admin", "standard", "admin", "standard", "admin", "standard", "admin", "standard", "admin", "standard", "admin"),
  name = c("User 1", "User 2", "User 3", "User 4", "User 5", "User 6", "User 7", "User 8", "User 9", "User 10", "User 11", "User 12", "User 13")
)

source("data_processing.R")

ui <- dashboardPage(
  skin = "black",
  # put the shinyauthr logout ui module in here
  dashboardHeader(
    title = tags$a(href='http://http://www.chmp-kenya.org/', tags$img(src='img/logo.png',height='40')),titleWidth = 230,
    tags$li(class = "dropdown", style = "padding: 8px;")
  ),
  
  #, shinyauthr::logoutUI("logout")
  # setup a sidebar menu to be rendered server-side
  dashboardSidebar(
    collapsed = FALSE, sidebarMenuOutput("sidebar")
  ),
  
  
  dashboardBody(
    shinyjs::useShinyjs(),
    
    # put the shinyauthr login ui module here
    shinyauthr::loginUI("login"),
    
    #setup any tab pages you want after login here with uiOutputs
      tabItems(

        tabItem(tabName = "qa",
                navbarPage("", id = "myNavbar",
                           tabPanel("Charts",

                                    selectInput("Yearqa", "Year", choices = c("2015", "2016", "2017",
                                                                              "2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                                    fluidRow(

                                      box(width = 6,title = "Number of Partner Complaints by Month",status = "primary",
                                          selectInput("nature",
                                                      label = "Complaint Type",
                                                      choices = c("Order cancellation","Quality Non-conformance" ,
                                                                  "Wrong Item Delivered/Invoiced", "Partner Mistake in Ordering",
                                                                  "Short Expiry" , "Breakage/Damaged",
                                                                  "Oversupply of Item(s)")),

                                          #uiOutput("naturecompl"),
                                          loadEChartsLibrary(),

                                          tags$div(id="partner_compl", style="width:100%;height:300px;"),
                                          deliverChart(div_id = "partner_compl")


                                      ),
                                      box(width = 6,title = "Number of Supplier Complaints by Month",status = "primary",

                                          selectInput("nature2",
                                                      label = "Complaint Type",
                                                      choices = c("Wrong item/Item not ordered","Quality non conformance" ,
                                                                  "Missing item/Undersupply/Package incomplete", "Short expiry/Expired",
                                                                  "Leaking /Broken Item/Damaged" , "COA Absent/Incomplete/Illegible",
                                                                  "Damaged packing", "Product specification", "Others"), selected = "Missing item/Undersupply/Package incomplete"),

                                          loadEChartsLibrary(),

                                          tags$div(id="sup_compl", style="width:100%;height:300px;"),
                                          deliverChart(div_id = "sup_compl")

                                      )
                                    ),
                                    fluidRow(
                                      box(width = 6,title = "Number of Suppliers by Month",status = "primary",

                                          loadEChartsLibrary(),

                                          tags$div(id="supplier_inc", style="width:100%;height:280px;"),
                                          deliverChart(div_id = "supplier_inc")

                                      ),

                                      box(width = 6,title = "CAPA-CARs-Process Observation",status = "primary",
                                          selectInput("Source", "Source", choices = c("Process Observation",  "Internal Audit")),

                                          loadEChartsLibrary(),

                                          tags$div(id="conformities", style="width:100%;height:200px;"),
                                          deliverChart(div_id = "conformities")

                                          #plotlyOutput("confo", height = '400px')

                                      )
                                    ),

                                    fluidRow(

                                      box(title = "Number of non conformities", width = 3,status = "primary",
                                          infoBoxOutput("critical", width = NULL),

                                          infoBoxOutput("major", width = NULL),

                                          infoBoxOutput("minor", width = NULL)
                                      ),



                                      box(width = 9,title = "Audits",status = "primary",
                                          box(
                                            width=6,title = "GLP Audits",
                                            loadEChartsLibrary(),

                                            tags$div(id="glpaud_bar", style="width:100%;height:200px;"),
                                            deliverChart(div_id = "glpaud_bar")),

                                          box(width=6,title = "GMP Audits",
                                              loadEChartsLibrary(),
                                              loadEChartsTheme('dark-digerati'),

                                              tags$div(id="gmpaud_bar", style="width:100%;height:200px"),
                                              deliverChart(div_id = "gmpaud_bar"))
                                      )
                                    ),
                                    fluidRow(

                                      box(title = "Number of Items Inspected", width = 3, status = "primary",

                                          plotlyOutput("qc", height = '200px')

                                      ),


                                      box(width = 5,status = "primary",
                                          selectInput("statusext", label = "Status of External Audit", choices = c("Completed","Continous","Under process","Status of CAPA unknown",
                                                                                                                   "Not applicable","Grand Total", Selected ="Continous")),

                                          # loadEChartsLibrary(),
                                          #
                                          # tags$div(id="auditextpie", style="width:100%;height:350px;"),
                                          # deliverChart(div_id = "auditextpie"),

                                          dataTableOutput("statusext", height = '360px'),
                                          downloadButton("downloadstts", "D")
                                          #formattableOutput("extauditstatus", height = "300px")
                                          # plotOutput("p",click = "plot_click"),
                                          #  textOutput("info"),
                                          #  tableOutput("table")
                                      ),

                                      box(width = 4,status = "primary",
                                          selectInput("status", label = "Status of Internal Audit", choices = c("Completed","Pending", selected ="Pending" )),

                                          dataTableOutput("internaud", height = '360px'),
                                          #formattableOutput("intauditstatus")

                                      )




                                    )),

                           tabPanel("QA Downloads",


                                    # formattableOutput("leavelist", height = '400px')
                                    #dataTableOutput("dataTable")
                           ))





        ),
        tabItem(tabName = "sa",
                selectInput("Year_sales", "Year", choices = c("2015","2016", "2017","2018", "2019","2020", "2021","2022", "5yrs Avg"), selected = "2020"),
                fluidRow(
                  box(
                    title = "Turnover by Destinations", width = 4, solidHeader = FALSE, status = "primary",
                    #
                    # loadEChartsLibrary(),
                    # loadEChartsTheme('shine'),
                    #
                    # tags$div(id="destin", style="width:100%;height:680px;"),
                    # deliverChart(div_id = "destin")
                    #

                    plotlyOutput("destinpie", height = "300px")

                  ),

                  box(
                    title = "Destinations Trends", width = 8, solidHeader = FALSE, status = "primary",

                    loadEChartsLibrary(),
                    loadEChartsTheme('shine'),

                    tags$div(id="destin2", style="width:100%;height:300px;"),
                    deliverChart(div_id = "destin2")

                  ),

                  box(
                    title = "Sales vs Requests (36 months)", width = 12, solidHeader = FALSE, status = "primary",

                    loadEChartsLibrary(),
                    loadEChartsTheme('shine'),

                    tags$div(id="salesrequests", style="width:100%;height:300px;"),
                    deliverChart(div_id = "salesrequests")

                  ),
                  box(
                    title = "Conversion Rate (36 months)", width = 6, solidHeader = FALSE, status = "primary",

                    loadEChartsLibrary(),
                    loadEChartsTheme('shine'),

                    tags$div(id="convrate2", style="width:100%;height:300px;"),
                    deliverChart(div_id = "convrate2")

                  ),

                  box(
                    title = "Turnover by Year", width = 6, solidHeader = FALSE, status = "primary",

                    loadEChartsLibrary(),
                    loadEChartsTheme('shine'),

                    tags$div(id="to_by_year", style="width:100%;height:300px;"),
                    deliverChart(div_id = "to_by_year")

                  ),




                  box(
                    title = "Turnover by Month and Year", width = 12, solidHeader = FALSE, status = "primary",

                    loadEChartsLibrary(),
                    loadEChartsTheme('shine'),

                    tags$div(id="annual_turnover", style="width:100%;height:300px;"),
                    deliverChart(div_id = "annual_turnover")

                  )


                )),

        tabItem(tabName = "hr",

                navbarPage("", id = "myNavbar",
                           tabPanel("HRA Information", fluidPage(

                             selectInput("Yearhr", "Year", choices = c("2015", "2016", "2017",
                                                                       "2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                             fluidRow(
                               box(
                                 title = "Staff per Department", width = 6, solidHeader = FALSE, status = "primary",

                                 # loadEChartsLibrary(),
                                 # loadEChartsTheme('shine'),
                                 #
                                 # tags$div(id="fullstaffdept", style="width:100%;height:350px;"),
                                 # deliverChart(div_id = "fullstaffdept")

                                 plotlyOutput("figDB", height = "320px")

                               ),

                               # box(title = "Total values", width = 3,
                               #
                               #     infoBoxOutput("progressBoxhr7", width = 3),
                               #     infoBoxOutput("female", width = 3),
                               #     infoBoxOutput("male", width = 3)
                               #
                               #
                               # ),

                               box(width = 3,solidHeader = TRUE,title = "Full time staff",
                                   #infoBoxOutput("backorders", width = 3),
                                   # A static infoBox
                                   infoBoxOutput("progressBoxhr7", width = NULL),
                                   infoBoxOutput("female", width = NULL),
                                   infoBoxOutput("male", width = NULL)

                               ),



                               box(width = 3,solidHeader = TRUE,title = "Casual staff",
                                   #infoBoxOutput("backorders", width = 3),
                                   # infoBoxOutput("backorders", width = 3),#total


                                   infoBoxOutput("progressBoxhr6", width = NULL),
                                   infoBoxOutput("femalec", width = NULL),
                                   infoBoxOutput("malec", width = NULL)


                               )),
                             fluidRow(
                               box(
                                 title = "Leave Day Distribution by Quarter", width = 12, solidHeader = FALSE, status = "primary",

                                 loadEChartsLibrary(),
                                 loadEChartsTheme('shine'),

                                 tags$div(id="num_leave", style="width:100%;height:350px;"),
                                 deliverChart(div_id = "num_leave")

                               )),







                             fluidRow(

                               box(width = 2, status = "primary", title = "Number of Leave Days Taken",
                                   infoBoxOutput("leave_q1", width = NULL),#renewed


                                   infoBoxOutput("leave_q2", width = NULL),
                                   infoBoxOutput("leave_q3",  width = NULL),
                                   infoBoxOutput("leave_q4",  width = NULL),
                               ),
                               box(width = 5, solidHeader = FALSE, status = "primary",title = "Number of Leave Days taken against the limit",
                                   br(),

                                   box(title = "Q1", flexdashboard::gaugeOutput("q1g", height = '120px')),
                                   box(title = "Q2",flexdashboard::gaugeOutput("q2g", height = '120px')),
                                   box(title = "Q3",flexdashboard::gaugeOutput("q3g", height = '120px')),
                                   box(title = "Q4",flexdashboard::gaugeOutput("q4g", height = '120px'))

                               ),
                               box(
                                 title = "Number of Staff Who took Leave", width = 5, solidHeader = FALSE, status = "primary",
                                 br(),
                                 loadEChartsLibrary(),
                                 loadEChartsTheme('shine'),

                                 tags$div(id="staffleave", style="width:100%;height:400px;"),
                                 deliverChart(div_id = "staffleave")

                                 #plotlyOutput("staffpie", height = "400px")

                               )
                             ),


                             infoBoxOutput("progressBoxhr3", width = 4)


                           )



                           ),
                           tabPanel("Leave Schedule",


                                    # formattableOutput("leavelist", height = '400px')
                                    DT::dataTableOutput("dataTable")
                           ))
        ),








        tabItem(tabName = "wh",
                selectInput("Year_wh", "Year", choices = c("2015","2016", "2017","2018", "2019","2020", "2021","2022", "5yrs Avg"), selected = "2019"),
                fluidRow(

                  box(width = 12, title = "Average Supplier Delivery per Day",
                      loadEChartsLibrary(),

                      tags$div(id="avgsupplier", style="width:100%;height:200px;"),
                      deliverChart(div_id = "avgsupplier")

                  ),
                  box(width = 12, title = "Number of Suppliers",
                      loadEChartsLibrary(),

                      tags$div(id="numsupplies", style="width:100%;height:200px;"),
                      deliverChart(div_id = "numsupplies")

                  ),
                  box(width = 12, title = "Number of Items Received",
                      loadEChartsLibrary(),

                      tags$div(id="numitems", style="width:100%;height:200px;"),
                      deliverChart(div_id = "numitems")

                  ),
                  box(width = 12, title = "Quantity Received",
                      loadEChartsLibrary(),

                      tags$div(id="quantreceived", style="width:100%;height:200px;"),
                      deliverChart(div_id = "quantreceived")

                  )

                ),

                fluidRow(

                  box(width = 12,title = "Number of Orders",
                      loadEChartsLibrary(),

                      tags$div(id="numorders", style="width:100%;height:200px;"),
                      deliverChart(div_id = "numorders")

                  ),

                  box(width = 12, title = "Average Order Processing Time",
                      loadEChartsLibrary(),

                      tags$div(id="avgtimeorder", style="width:100%;height:200px;"),
                      deliverChart(div_id = "avgtimeorder")

                  ),
                  box(width = 12, title = "Maintenance Cost",
                      loadEChartsLibrary(),

                      tags$div(id="costmaintain", style="width:100%;height:200px;"),
                      deliverChart(div_id = "costmaintain")

                  )


                  #   box(width = 2,title = "Order accuracy",status = "primary",
                  #
                  #       gaugeOutput("gauge", height = '200px')
                  # ))

                )
        ),

        tabItem(tabName = "pr",
                selectInput("Yearpr", "Year", choices = c("2015", "2016", "2017",
                                                          "2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                fluidRow(
                  box(title = "Total values", width = 12,

                      infoBoxOutput("backorders", width = 3),

                      infoBoxOutput("stockval",  width = 3),
                      infoBoxOutput("purch", width = 3),#renewed
                      infoBoxOutput("approvalBox7f", width = 3),


                  )),
                fluidRow(


                  box(width = 12,title = "Stock Value Per Month ",solidHeader = TRUE,

                      loadEChartsLibrary(),
                      tags$div(id="stockmonth", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "stockmonth")),
                  box(width = 12,title = "Number of Items Procured",solidHeader = TRUE,

                      loadEChartsLibrary(),
                      tags$div(id="procmonth", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "procmonth"))

                ),
                fluidRow(
                  box(width = 12,title = "Back Orders Value ",solidHeader = TRUE,
                      loadEChartsTheme("infographic"),
                      loadEChartsLibrary(),
                      tags$div(id="backorderschart", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "backorderschart"))),

                fluidRow( box(title = "Total values", width = 12,

                              infoBoxOutput("bbvalue", width = 3),
                              infoBoxOutput("savevalue",  width = 3),
                              infoBoxOutput("approvalBox7c", width = 3),
                              infoBoxOutput("approvalBox7b", width = 3)

                )),

                fluidRow(
                  box(width = 12,title = "Savings per Month",solidHeader = TRUE,
                      loadEChartsTheme("macarons"),
                      loadEChartsLibrary(),
                      tags$div(id="savingsmonth", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "savingsmonth")),

                  box(width = 12,title = "Value of Items Returned to Supplier",solidHeader = TRUE,

                      loadEChartsLibrary(),
                      tags$div(id="returntosup", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "returntosup"))),


                box(width = 12,title = "Purchases Value",solidHeader = TRUE,

                    loadEChartsLibrary(),
                    tags$div(id="purchases", style="width:100%;height:200px;"),
                    ECharts2Shiny::deliverChart(div_id = "purchases")),


                # infoBoxOutput("backorders", width = 3),#total




                fluidRow(
                  box(width = 12,title = "Value of Bad Boys",solidHeader = TRUE,

                      loadEChartsLibrary(),
                      tags$div(id="badboy_value", style="width:100%;height:200px;"),
                      ECharts2Shiny::deliverChart(div_id = "badboy_value"))


                )),

        #
        tabItem(tabName = "os",
                selectInput("Yearos", "Year", choices = c("2015", "2016", "2017",
                                                          "2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                fluidRow(

                  box(
                    title = "OSH (Trainings by Type)", width = 12, solidHeader = TRUE,

                    loadEChartsLibrary(),

                    tags$div(id="oshtrain", style="width:100%;height:300px;"),
                    deliverChart(div_id = "oshtrain")
                  )
                  # box(
                  #   title = "OSH(Audit by Type)", width = 6, solidHeader = TRUE,
                  #
                  #   loadEChartsLibrary(),
                  #
                  #   tags$div(id="auditbar", style="width:100%;height:300px;"),
                  #   deliverChart(div_id = "auditbar")
                  # )



                ),

                h2("IT CHARTS"),
                fluidRow(
                  box(width = 3,solidHeader = TRUE,
                      #infoBoxOutput("backorders", width = 3),
                      # A static infoBox
                      infoBoxOutput("approvalBox8c", width = NULL),
                      infoBoxOutput("progressBox8", width = NULL),
                      infoBoxOutput("approvalBox8b", width = NULL)

                  ),

                  box(

                    title = "Incidences by Department and Type", width = 3, solidHeader = TRUE,

                    selectInput("Location", "Department", choices = c("Quality control office", "Warehouse",
                                                                      "Human Resources office", "Procurement Office"), selected="Warehouse"),
                    plotlyOutput("injury", height = '300px')
                  ),

                  box(title = "Consumables",width = 5,solidHeader = TRUE,
                      formattableOutput("consumab"),
                      #formattableOutput("intauditstatus")
                  ),

                  # box(
                  #   title = "User trainings", width = 4, solidHeader = TRUE,
                  #
                  #   loadEChartsLibrary(),
                  #
                  #   tags$div(id="filt2;", style="width:100%;height:400px;"),
                  #   deliverChart(div_id = "filt2")
                  # ),
                  #



                  box(title = "User Issues and Turnaround Time",width = 5, solidHeader = TRUE,
                      formattableOutput("issues_IT")),


                )
        ),


        tabItem(tabName = "fin",
                selectInput("Yearfin", "Year", choices = c("2015", "2016", "2017","2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                fluidRow(
                  box(
                    title = "Income vs Expenditure", width = 12, solidHeader = TRUE,

                    loadEChartsLibrary(),
                    loadEChartsTheme("macarons"),

                    tags$div(id="inc2", style="width:100%;height:400px;"),
                    deliverChart(div_id = "inc2")
                  )),

                fluidRow(
                  box(width = 12,solidHeader = TRUE,
                      #infoBoxOutput("backorders", width = 3),
                      # A static infoBox
                      infoBoxOutput("finBox1", width = 4),
                      infoBoxOutput("finBox2", width = 4),
                      infoBoxOutput("finBox3", width = 4)

                  )),
                fluidRow(
                  box(
                    title = "Monthly Turnover", width = 12, solidHeader = TRUE,

                    loadEChartsLibrary(),
                    loadEChartsTheme("vintage"),

                    tags$div(id="turnover", style="width:100%;height:270px;"),
                    deliverChart(div_id = "turnover")
                  ))

        ),




        # fluidRow(
        #   box(
        #     title = "Income & Expenditure", width = 6, solidHeader = TRUE,
        #
        #     loadEChartsLibrary(),
        #
        #     tags$div(id="inc2", style="width:100%;height:400px;"),
        #     deliverChart(div_id = "inc2")
        #   )
        #
        # )


        tabItem(tabName = "risk",
                selectInput("Yearrisk", "Year", choices = c("2015", "2016", "2017",
                                                            "2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020"),
                box(width = 4,title = "Risk log",status = "primary",

                    selectInput("risk", "Risk Type", choices = c("High", "medium", "low")),
                    loadEChartsLibrary(),

                    tags$div(id="risk_cat", style="width:100%;height:200px;"),
                    deliverChart(div_id = "risk_cat")
                ),

                box(title="Risks", width = 5,height = '340px',solidHeader = TRUE,
                    selectInput("dept", "Department", choices = c("Quality control", "Warehouse",
                                                                  "Human Resources", "Procurement", "IT", "Sales"), selected="Sales"),
                    formattableOutput("risk")),

        )

      )
  )
)

server <- function(input, output, session) {
  
  # login status and info will be managed by shinyauthr module and stores here
  credentials <- callModule(shinyauthr::login, "login", 
                            data = user_base,
                            user_col = user,
                            pwd_col = password,
                            sodium_hashed = TRUE,
                            log_out = reactive(logout_init()))
  
  # logout status managed by shinyauthr module and stored here
  logout_init <- callModule(shinyauthr::logout, "logout", reactive(credentials()$user_auth))
  
  # this opens or closes the sidebar on login/logout
  observe({
    if(credentials()$user_auth) {
      shinyjs::removeClass(selector = "body", class = "sidebar-collapse")
    } else {
      shinyjs::addClass(selector = "body", class = "sidebar-collapse")
    }
  })
  
  # only when credentials()$user_auth is TRUE, render your desired sidebar menu
  output$sidebar <- renderMenu({
    req(credentials()$user_auth)
    sidebarMenu(id = "tabs",
                #menuItem("Home", tabName = "tab1", icon = shiny::icon("clipboard-check",lib = "font-awesome"), selected =TRUE),
                menuItem("QA", tabName = "qa", icon = shiny::icon("check-square-o", lib = "font-awesome")),
                menuItem("Sales & Marketing", tabName = "sa", icon = shiny::icon("dollar",lib = "font-awesome")),
                menuItem("Procurement", tabName = "pr", icon = shiny::icon("shopping-cart",lib = "font-awesome")),
                menuItem("Warehouse & Distribution", tabName = "wh", icon = shiny::icon("building-o", lib = "font-awesome")), 
                menuItem("HR", tabName = "hr", icon = shiny::icon("users", lib = "font-awesome")),
                menuItem("OSH & IT", tabName = "os", icon = shiny::icon("laptop", lib = "font-awesome")),
                menuItem("Finance", tabName = "fin", icon = shiny::icon("money", lib = "font-awesome")),
                menuItem("Risk", tabName = "risk", icon = shiny::icon("exclamation-triangle", lib = "font-awesome"))
                #selectInput("variable", label = "month", choices = c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", "TBD", "All"), selected = "All")
                # selectInput("Year", "Year Select", choices = c("2015", "2016", "2017","2018", "2019", "2020", "2021", "5yrs Avg"), selected = "2020")
                
                
    )
  })
  
  observeEvent(input$button, {
    insertTab(inputId = "myNavbar",
              tabPanel("Dynamic", "This a dynamically-added tab"),
              position = 'after',
              target = "tab1.2"
    )
    
  })
  
  output$distPlot <- renderPlotly({
    
    p <-
      ggplot(data = partner, mapping = aes(x = reorder(partner, counts), counts))+
      geom_bar(fill = "#69b3a2", stat = "identity") +
      
      geom_text(aes(label = counts), vjust = -0.3) +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
      
      coord_flip()+
      xlab("") +
      ylab("")
    
    #theme_pubclean()
    
    ggplotly(p)
    p
  })
  
  
  # # output$distPlot <- renderPlotly({
  #  p <- partner %>%
  #   filter(!is.na(counts)) %>%
  #   arrange(counts) %>%
  #   tail(20) %>%
  #   mutate(Partner =factor(Partner , Partner )) %>%
  #   ggplot( aes(x=Partner, y=counts) ) +
  #   geom_bar(stat="identity", fill="#69b3a2") +
  #   coord_flip() +
  #   theme_ipsum() +
  #   theme(
  #     panel.grid.minor.y = element_blank(),
  #     panel.grid.major.y = element_blank(),
  #     legend.position="none"
  #   ) +
  #   xlab("") +
  #   ylab("")
  # # 
  # #  ggplotly(p)
  # #     p
  # # })
  
  #sales charts
  #graph 1 destination
  
  filtered_destin<- reactive({
    
    pievalues2 %>%
      filter(Year == input$Year_sales) %>%
      dplyr::select(c("name", "value"))
  })
  
  output$destinpie <- renderPlotly ({
    fig <- plot_ly(filtered_destin(), labels = ~name, values = ~value, type = 'pie')
    fig <- fig %>% layout(
      xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
      yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
    fig
    #
  })
  # 
  # 
  observeEvent(filtered_destin(),
               {
                 renderPieChart(div_id = "destin",
                                theme = 'vintage',
                                show.label = TRUE,
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend= 12,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = filtered_destin())
               })
  # 
  # filtered_destin<- reactive({
  #   
  #   pievalues2 %>% 
  #     as.data.frame() %>%  
  #     column_to_rownames(var = "Year")
  # })
  # 
  # # output$destinpie <- renderPlotly ({
  # #   fig <- plot_ly(filtered_destin(), labels = ~name, values = ~value, type = 'pie')
  # #   fig <- fig %>% layout(
  # #     xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
  # #     yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  # #   
  # #   fig
  # #   
  # # })
  # 
  # observeEvent(filtered_destin(),
  #              {
  #                
  #                renderLineChart(div_id = "destin", theme = 'vintage',
  #                                line.width = 2, line.type = "solid",
  #                                point.size = 5, point.type = "roundRect",
  #                                stack_plot = FALSE, step = "null",
  #                                show.legend = FALSE, show.tools = TRUE,
  #                                font.size.legend= 12,
  #                                font.size.axis.x = 12, font.size.axis.y = 12,
  #                                axis.x.name = NULL, axis.y.name = "KES",
  #                                rotate.axis.x = 0, rotate.axis.y = 0, 
  #                                show.slider.axis.x = FALSE, show.slider.axis.y = FALSE,
  #                                animation = TRUE,
  #                                grid_left = "3%", grid_right = "4%", grid_top = "16%", grid_bottom = "3%",
  #                               data = filtered_destin())
  #              })
  #graph 2 destination
  
  filtered_destin2<- reactive({
    destination4 %>% 
      as.data.frame() %>%  
      column_to_rownames(var = "variable")
    #%>%  
    #select("2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017",
    #"2018", "2019", "2020")
    
  })
  
  observeEvent(filtered_destin2(),
               {
                 
                 renderLineChart(div_id = "destin2",theme = 'vintage',
                                 line.width = 2, line.type = "solid",
                                 point.size = 5, point.type = "roundRect",
                                 stack_plot = FALSE, step = "null",
                                 show.legend = FALSE, show.tools = TRUE,
                                 font.size.legend= 12,
                                 font.size.axis.x = 12, font.size.axis.y = 12,
                                 axis.x.name = NULL, axis.y.name = "KES",
                                 rotate.axis.x = 0, rotate.axis.y = 0, 
                                 show.slider.axis.x = FALSE, show.slider.axis.y = FALSE,
                                 animation = TRUE,
                                 grid_left = "3%", grid_right = "4%", grid_top = "16%", grid_bottom = "3%",
                                 data = filtered_destin2())
               })
  
  #conversion rate
  filtered_conrate<- reactive({
    convrates %>% 
      as.data.frame() %>%  
      dplyr::select(Month3, Conversion_rate2)%>% 
      set_colnames(c("Month", "Conversion rate (%)")) %>%
      column_to_rownames(var = "Month")
    #%>%  
    #select("2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017",
    #"2018", "2019", "2020")
    
  })
  
  
  observeEvent(filtered_conrate(),
               {
                 
                 renderLineChart(div_id = "convrate2",theme = 'vintage',
                                 line.width = 2, line.type = "solid",
                                 point.size = 5, point.type = "diamond",
                                 stack_plot = FALSE, step = "null",
                                 show.legend = FALSE, show.tools = FALSE,
                                 font.size.legend= 12,
                                 font.size.axis.x = 12, font.size.axis.y = 12,
                                 axis.x.name = NULL, axis.y.name = "Percentage",
                                 rotate.axis.x = 0, rotate.axis.y = 0,
                                 show.slider.axis.x = FALSE, show.slider.axis.y = FALSE,
                                 animation = TRUE,
                                 grid_left = "3%", grid_right = "4%", grid_top = "16%", grid_bottom = "3%",
                                 data = filtered_conrate())
               })
  
  #sales vs requests
  sales_req<- reactive({
    convrates %>% 
      as.data.frame() %>%  
      dplyr::select(Month3, Requested, Invoiced)%>% 
      set_colnames(c("Month", "Requested", "Invoiced")) %>%
      column_to_rownames(var = "Month")
    #%>%  
    #select("2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017",
    #"2018", "2019", "2020")
    
  })
  
  
  observeEvent(sales_req(),
               {
                 
                 renderLineChart(div_id = "salesrequests",theme = 'vintage',
                                 line.width = 2, line.type = "solid",
                                 point.size = 5, point.type = "diamond",
                                 stack_plot = FALSE, step = "null",
                                 show.legend = FALSE, show.tools = TRUE,
                                 font.size.legend= 12,
                                 font.size.axis.x = 12, font.size.axis.y = 12,
                                 axis.y.name = "Percentage",
                                 rotate.axis.x = 0, rotate.axis.y = 0,
                                 show.slider.axis.x = FALSE, show.slider.axis.y = FALSE,
                                 animation = TRUE,
                                 grid_left = "3%", grid_right = "4%", grid_top = "16%", grid_bottom = "3%",
                                 data = sales_req())
               })
  
  #TO by months per year
  annual<- reactive({ 
    annualturnover3 %>% 
      as.data.frame() %>%  
      dplyr::select(Year,Jan,Feb, Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)%>%
      #filter(Year == input$Year_sales)%>%
      column_to_rownames(var = "Year")
    
  })
  
  observeEvent(annual(),
               {
                 renderBarChart(div_id = "annual_turnover", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.y.name = "KES",
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = annual())
               })
  
  #TO by year
  tofilt<- reactive({ 
    tobyyear2  %>% 
      as.data.frame() %>%  
      set_colnames(c("Year", "Turnover"))%>% 
      #filter(Year == input$Year_sales)%>%
      column_to_rownames(var = "Year")
    
  })
  
  observeEvent(tofilt(),
               {
                 renderBarChart(div_id = "to_by_year", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.y.name = "KES",
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = tofilt())
               })
  
  
  #########PROCUREMENT##############
  #backorders
  monthly<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(BACK_ORDERS)
  })
  
  observeEvent(monthly(),
               {
                 renderBarChart(div_id = "backorderschart", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "infographic", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES(M)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = monthly())
               })
  
  #value of purchases
  monthlypurch<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(PURCHASES)
  })
  
  observeEvent(monthlypurch(),
               {
                 renderBarChart(div_id = "purchases", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES(M)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = monthlypurch())
               })
  
  #bad boy value 
  badboyval<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(BAD_BOYS)
  })
  
  observeEvent(badboyval(),
               {
                 renderBarChart(div_id = "badboy_value", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES(M)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = badboyval())
                 
               })
  #ITEMS PROCURED
  monthlyproc<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(ITEMS_PROCURED )
  })
  
  observeEvent(monthlyproc(),
               {
                 
                 
                 renderLineChart(div_id = "procmonth", grid_left = '1%', stack_plot =FALSE,axis.y.name = "KES (K)",theme = "vintage", show.legend = FALSE,
                                 
                                 
                                 data = monthlyproc())
               })
  
  #value of stock
  stockval<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(STOCK_VALUE )
  })
  
  observeEvent(stockval(),
               {
                 
                 
                 renderBarChart(div_id = "stockmonth", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES (K)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                
                                data = stockval())
               })
  
  #savings
  savings<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(SAVINGS )
  })
  
  observeEvent(savings(),
               {
                 renderBarChart(div_id = "savingsmonth", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES (K)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = savings())
               })
  
  #items returned
  returned<- reactive({ 
    monthlyrep3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearpr)%>%
      column_to_rownames(var = "MONTH") %>%
      dplyr::select(SUP_RETURNS )
  })
  
  observeEvent(returned(),
               {
                 renderBarChart(div_id = "returntosup", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,axis.y.name = "KES (K)",
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = returned())
               })
  
  
  
  #total back orders
  filtered_bord<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(BACKORDERS ) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_bord(),
               {
                 output$backorders <- renderInfoBox({
                   infoBox(
                     "Back orders", format(filtered_bord(), big.mark = ","), icon = icon("retweet"),
                     color = "navy"
                   )
                 })
               })
  
  #total purchases
  purchases<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(PURCHASES) %>% magrittr::extract(1)
  })
  
  observeEvent(purchases(),
               {
                 output$purch <- renderInfoBox({
                   infoBox(
                     "Purchases", format(purchases(), big.mark = ","), icon = icon("money"),
                     color = "light-blue"
                   )
                 })
               })
  
  #total stock value
  stock<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(STOCKVALUE) %>% magrittr::extract(1)
  })
  
  observeEvent(stock(),
               {
                 output$stockval <- renderInfoBox({
                   infoBox(
                     "Stock", format(stock(), big.mark = ","), icon = icon("bar-chart"),
                     color = "yellow"
                   )
                 })
               })
  
  #total badboy value
  bbval<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(BADBOYSVALUE) %>% magrittr::extract(1)
  })
  
  observeEvent(bbval(),
               {
                 output$bbvalue <- renderInfoBox({
                   infoBox(
                     "Bad boys", format(bbval(), big.mark = ","), icon = icon("reddit-alien"),
                     color = "navy"
                   )
                 })
               })
  
  #total savings value
  savingsval<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(SAVINGS) %>% magrittr::extract(1)
  })
  
  observeEvent(savingsval(),
               {
                 output$savevalue <- renderInfoBox({
                   infoBox(
                     "Savings", format(savingsval(), big.mark = ","), icon = icon("envelope-open"),
                     color = "yellow"
                   )
                 })
               })
  
  valueitems<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(ITEMS_PROCURED) %>% magrittr::extract(1)
  })
  
  observeEvent(valueitems(),
               {
                 output$approvalBox7f <- renderInfoBox({
                   infoBox(
                     "Number procured", format(valueitems(), big.mark = ","), icon = icon("list-ol"),
                     color = "purple"
                   )
                 })
               })
  
  #donations
  donitems<- reactive({
    donations4 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(VALUE) %>% magrittr::extract(1)
  })
  
  observeEvent(donitems(),
               {
                 output$approvalBox7b <- renderInfoBox({
                   infoBox(
                     "Items donated", format(donitems(), big.mark = ","), icon = icon("gift"),
                     color = "purple"
                   )
                 })
               })
  
  supret<- reactive({
    totals %>%
      #as.data.frame() %>%
      filter(Year == input$Yearpr)%>%
      magrittr::use_series(RETURNTOSUP) %>% magrittr::extract(1)
  })
  
  observeEvent(supret(),
               {
                 output$approvalBox7c <- renderInfoBox({
                   infoBox(
                     "Items returned", format(supret(), big.mark = ","), icon = icon("handshake-o"),
                     color = "red"
                   )
                 })
               })
  # nearexp<- reactive({
  #   singlepro %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearpr, Month ==input$variable)%>%
  #     magrittr::use_series(nearexpiry) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(nearexp(),
  #              {
  #                output$approvalBox7d <- renderInfoBox({
  #                  infoBox(
  #                    "Value of goods nearing expiry", format(nearexp(), big.mark = ","), icon = icon("trash-o"),
  #                    color = "yellow"
  #                  )
  #                })
  #              })
  
  #items table
  filtered_itemspr<- reactive({
    itemlist2 %>%
      filter(Year==input$Yearpr, Month==input$variable) %>%
      dplyr::select(variable, value)%>%
      set_colnames(c("Rank", "Item name"))
    
  })
  
  output$itemspr <- renderFormattable({
    risk <- formattable(filtered_itemspr(), list(
      # Rating = formatter("span",
      #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
      #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
      #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  
  # bad_boys<- reactive({
  #   singlepro %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearpr, Month ==input$variable)%>%
  #     magrittr::use_series(badboys) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(bad_boys(),
  #              {
  #                output$gaugepr1 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(bad_boys(),
  #                                       min = 0, max = 2000000, flexdashboard::gaugeSectors(
  #                                         danger = c(100000, 999999), warning = c(1000000,1490000 ), success = c(1500000,2000000)))
  #                  
  #                })
  #              })
  # money_saved<- reactive({
  #   singlepro %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearpr, Month ==input$variable)%>%
  #     magrittr::use_series(moneysaved) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(money_saved(),
  #              {
  #                output$gaugepr2 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(money_saved(),
  #                                       min = 0, max = 1000000, flexdashboard::gaugeSectors(
  #                                         danger = c(100000, 390000), warning = c(400000,790000 ), success = c(800000,1000000)))
  #                  
  #                })
  #              })
  # # 
  # back_orders<- reactive({
  #   singlepro %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearpr, Month ==input$variable)%>%
  #     magrittr::use_series(backorders) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(back_orders(),
  #              {
  #                output$gaugepr3 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(back_orders(),
  #                                       min = 0, max = 10000000, flexdashboard::gaugeSectors(
  #                                         danger = c(1000000, 3900000), warning = c(4000000,7900000 ), success = c(8000000,10000000)))
  #                  
  #                })
  #              })
  # 
  # cpro <- reactive({
  #   if(!input$variable == "All"){
  #     catpro2 %>% 
  #       filter(variable == input$variable & Year == input$Yearpr) %>%
  #       group_by(category) %>%
  #       summarise(mean_active = sum(value))
  #   }else{
  #     catpro2 %>% 
  #       filter(Year == input$Yearpr) %>%
  #       group_by(category) %>%
  #       summarise(mean_active = sum(value))
  #   }
  #   #as.data.frame(tezt2)
  #   #names(tezt2)<- c("partner", "counts")
  # })
  # 
  # output$catpro_mg <- renderPlotly({
  #   
  #     
  #   #   ggplot(data = cpro(), mapping = aes(x = category, mean_active, group = factor(frequency())))+
  #   #   geom_bar(stat='identity', fill='#4179ab') +
  #   #   
  #   #   geom_text(aes(label = mean_active), vjust = -0.3, size=3) +
  #   #   theme_void() +
  #   #   xlab(frequency()) + 
  #   #   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  #   # 
  #   # coord_flip()
  #   # 
  #   # ggplotly(p)
  #   # p
  #   p <-
  #     ggplot(data = cpro(), mapping = aes(x = reorder(category, mean_active), mean_active))+
  #     geom_bar(fill = "#69b3a2", stat = "identity") +
  #     
  #     geom_text(aes(label = mean_active), vjust = -0.3) +
  #     theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  #     
  #     coord_flip()+
  #     xlab("") +
  #     ylab("")
  # })
  #suppliers
  sup <- reactive({
    if(!input$variable == "All"){
      catsup2 %>% 
        filter(variable == input$variable & Year == input$Yearpr) %>%
        group_by(supplier) %>%
        summarise(mean_active = sum(value))
    }else{
      catsup2 %>% 
        filter(Year == input$Yearpr) %>%
        group_by(supplier) %>%
        summarise(mean_active = sum(value))
    }
    #as.data.frame(tezt2)
    #names(tezt2)<- c("partner", "counts")
  })
  
  output$catsup_mg <- renderPlotly({
    # p <-
    #   
    #   ggplot(data = sup(), mapping = aes(x = supplier, mean_active, group = factor(frequency())))+
    #   geom_bar(stat='identity', fill='#4179ab') +
    #   
    #   geom_text(aes(label = mean_active), vjust = -0.3, size=3) +
    #   theme_void() +
    #   xlab(frequency()) + 
    #   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
    # 
    # coord_flip()
    # 
    # ggplotly(p)
    # p
    p <-
      ggplot(data = sup(), mapping = aes(x = reorder(supplier, mean_active), mean_active))+
      geom_bar(fill = "#69b3a2", stat = "identity") +
      
      geom_text(aes(label = mean_active), vjust = -0.3) +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
      
      coord_flip()+
      xlab("") +
      ylab("")
    
  })
  
  
  # genres<- reactive({
  #   singlepro %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearpr, Month ==input$variable)%>%
  #     magrittr::use_series(genresources) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(genres(),
  #              {
  #                output$approvalBox7e <- renderInfoBox({
  #                  infoBox(
  #                    "Value of general resources", format(genres(), big.mark = ","), icon = icon("pie-chart"),
  #                    color = "yellow"
  #                  )
  #                })
  #              })
  # 
  ######HR charts#################################
  #leave information
  filtered_lv<- reactive({
    leaveinfo3 %>%
      filter(Year==input$Yearhr) 
    
  })
  
  
  output$dataTable <- DT::renderDataTable(
    DT::datatable(
      filtered_lv(), options = list(
        lengthMenu = list(c(27)), 
        pageLength = 27
      )
    )
  )
  
  # output$dataTable <- DT::renderDT(
  #   filtered_lv(), # data
  #   class = "display nowrap compact", # style
  #   filter = "top" ,
  #   options = list(scrollX = TRUE)# location of column filters
  # )
  
  
  
  output$leavelist <- renderFormattable({
    risk <- formattable(filtered_lv(), list(
      # Rating = formatter("span",
      #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
      #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
      #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  
  
  #LEAVE PLANNER table
  numleave<- reactive({ 
    leaveinfo6 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr)%>%
      column_to_rownames(var = "variable") %>%
      dplyr::select(-c(Year))
  })
  
  observeEvent(numleave(),
               {
                 renderBarChart(div_id = "num_leave", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = numleave())
                 
               })
  
  #leave summary
  q1leave<- reactive({ 
    staff_leave %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr)%>%
      summarise(n = sum(Q1))%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
    
  })
  q2leave<- reactive({ 
    staff_leave %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr)%>%
      summarise(n = sum(Q2))%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
    
  }) 
  
  q3leave<- reactive({ 
    staff_leave %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr)%>%
      summarise(n = sum(Q3))%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
    
  })
  q4leave<- reactive({ 
    staff_leave %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr)%>%
      summarise(n = sum(Q4))%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
    
  })
  
  #staff that took leave
  q1staff<- reactive({ 
    staff_leave2 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearhr, value == "took leave")%>%
      #group_by(variable, value) %>%
      summarise(variable2,value)%>%
      dplyr::count(variable2)%>%
      column_to_rownames(var = "variable2")
    
  })
  
  
  observeEvent(q1staff(),
               {
                 renderBarChart(div_id = "staffleave", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = q1staff())
               })
  
  
  observeEvent(q1leave(),
               {
                 output$leave_q1 <- renderInfoBox({
                   infoBox(
                     "Q1",  format(q1leave(), big.mark = ","), icon = icon("check-square"),
                     color = "olive", fill =TRUE, width = 3
                   )
                 })
               }) 
  
  observeEvent(q1leave(),
               {
                 output$q1g = flexdashboard::renderGauge({
                   flexdashboard::gauge(q1leave(),
                                        min = 0, max = 100,symbol = '%', flexdashboard::gaugeSectors(
                                          danger = c(99.9,100), warning = c(10, 39), success = c(40,99.8)))
                   
                 })
               })
  observeEvent(q2leave(),
               {
                 output$leave_q2 <- renderInfoBox({
                   infoBox(
                     "Q2",  format(q2leave(), big.mark = ","), icon = icon("check-square"),
                     color = "olive", fill =TRUE,width = 3
                   )
                 })
               }) 
  
  observeEvent(q2leave(),
               {
                 output$q2g = flexdashboard::renderGauge({
                   flexdashboard::gauge(q2leave(),
                                        min = 0, max = 100,symbol = '%', flexdashboard::gaugeSectors(
                                          danger = c(99.9,100), warning = c(10, 39), success = c(40,99.8)))
                   
                 })
               })
  
  observeEvent(q3leave(),
               {
                 output$leave_q3 <- renderInfoBox({
                   infoBox(
                     "Q3",  format(q3leave(), big.mark = ","), icon = icon("check-square"),
                     color = "olive", fill =TRUE,width = 3
                   )
                 })
               }) 
  
  observeEvent(q3leave(),
               {
                 output$q3g = flexdashboard::renderGauge({
                   flexdashboard::gauge(q3leave(),
                                        min = 0, max = 100,symbol = '%', flexdashboard::gaugeSectors(
                                          danger = c(99.9,100), warning = c(10, 39), success = c(40,99.8)))
                   
                 })
               })
  
  observeEvent(q4leave(),
               {
                 output$leave_q4 <- renderInfoBox({
                   infoBox(
                     "Q4",  format(q4leave(), big.mark = ","), icon = icon("check-square"),
                     color = "olive", fill =TRUE,width = 3
                   )
                 })
               }) 
  
  observeEvent(q4leave(),
               {
                 output$q4g = flexdashboard::renderGauge({
                   flexdashboard::gauge(q4leave(),
                                        min = 0, max = 100,symbol = '%', flexdashboard::gaugeSectors(
                                          danger = c(99.9,100), warning = c(10, 39), success = c(40,99.8)))
                   
                 })
               })
  # vb <-  valueBox(
  #   value = "1,345",
  #   subtitle = "Lines of code written",
  #   icon = icon("code"),
  #   width = 4,
  #   color = "red",
  #   href = NULL)
  # output$vbox <- renderValueBox(vb)
  
  observeEvent(numleave(),
               {
                 renderBarChart(div_id = "num_leave", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = numleave())
               })
  
  
  
  # fulltime
  full_time<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "FULLTIME")%>%
      dplyr::count(Status)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(full_time(),
               {
                 output$progressBoxhr7 <- renderInfoBox({
                   infoBox(
                     "Total number", format(full_time(), big.mark = ","), icon = icon("group"),
                     color = "orange", fill = TRUE
                   )
                 })
               })
  
  
  
  
  #  # fulltime female
  # full_fem<- reactive({
  #   staff_data2 %>%
  #     #as.data.frame() %>%
  #     filter(Year == 2020, Status == "FULLTIME")%>%
  #     count(Gender)%>%
  #     set_colnames("name", "value")
  #   
  # })
  # 
  # observeEvent(full_fem(),
  #              {
  #                renderPieChart(div_id = "gender_dept",show.label = TRUE,show.legend = FALSE,
  #                               data = full_fem())
  #              })
  full_fem<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "FULLTIME", Gender == "F")%>%
      dplyr::count(Gender)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(full_fem(),
               {
                 output$female <- renderInfoBox({
                   infoBox(
                     "FEMALE", format(full_fem(), big.mark = ","), icon = icon("female"),
                     color = "orange"
                   )
                 })
               })
  
  
  # fulltime male
  full_male<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "FULLTIME", Gender == "M")%>%
      dplyr::count(Gender)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(full_male(),
               {
                 output$male <- renderInfoBox({
                   infoBox(
                     "MALE", format(full_male(), big.mark = ","), icon = icon("male"),
                     color = "orange"
                   )
                 })
               })
  
  # casuals
  casuals<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "CASUAL")%>%
      dplyr::count(Status)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(casuals(),
               {
                 output$progressBoxhr6 <- renderInfoBox({
                   infoBox(
                     "Total number", format(casuals(), big.mark = ","), icon = icon("group"),
                     color = "light-blue", fill = TRUE
                   )
                 })
               })
  
  # casual female
  cas_fem<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "CASUAL", Gender == "F")%>%
      dplyr::count(Gender)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(cas_fem(),
               {
                 output$femalec <- renderInfoBox({
                   infoBox(
                     "FEMALE", format(cas_fem(), big.mark = ","), icon = icon("female"),
                     color = "light-blue"
                   )
                 })
               })
  
  # casual male
  cas_male<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Status == "CASUAL", Gender == "M")%>%
      dplyr::count(Gender)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(full_male(),
               {
                 output$malec <- renderInfoBox({
                   infoBox(
                     "MALE", format(cas_male(), big.mark = ","), icon = icon("male"),
                     color = "light-blue"
                   )
                 })
               })
  
  #staff by dept
  filtered_staff<- reactive({
    
    staff_data2 %>% 
      filter(Year == input$Yearhr) %>%
      dplyr::count(Department2) %>%
      set_colnames(c("name", "value"))
  })
  
  output$figDB <- renderPlotly ({
    fig <- plot_ly(filtered_staff(), labels = ~name, values = ~value, type = 'pie')
    fig <- fig %>% layout(
      xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
      yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
    fig
    
  })
  
  # observeEvent(filtered_staff(),
  #              {
  #                renderPieChart(div_id = "fullstaffdept",show.label = TRUE,show.legend = FALSE,
  #                               data = filtered_staff())
  #              })
  
  # disciplinary
  filtered_disc<- reactive({
    staff_data2 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearhr, Disciplinary_action2 == "Yes")%>%
      dplyr::count(Disciplinary_action2)%>%
      magrittr::use_series(n) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_disc(),
               {
                 output$progressBoxhr3 <- renderInfoBox({
                   infoBox(
                     "Number of Disciplinary Cases",  format(filtered_disc(), big.mark = ","), icon = icon("balance-scale"),
                     color = "red"
                   )
                 })
               }) 
  
  # filtered_itemspr<- reactive({
  #   leave19 %>%
  #     filter(Year==input$Year, Month==input$variable) %>%
  #     select(variable, value)%>%
  #     set_colnames(c("Rank", "Item name"))
  #   
  # })
  
  output$leave2019 <- renderFormattable({
    risk <- formattable(leave19, list(
      # Rating = formatter("span",
      #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
      #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
      #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  
  
  
  ####IT charts
  
  #issues for IT
  filt_issues<- reactive({
    issues %>%
      #as.data.frame() %>%
      filter(Year == input$Yearos) %>%
      dplyr::select(Month,Issue, Occurrence, Avg_downtime_min, Avg_repair_time_min, users_supported)%>%
      set_colnames(c("Month","Issue", "Occurrence", "Avg downtime (min)", "Avg repair time (min)", "Users supported"))
    
  })
  
  output$issues_IT <- renderFormattable({
    risk <- formattable(filt_issues(), list(
      # Rating = formatter("span",
      #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
      #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
      #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  
  #CONSUMABLES
  consume <- reactive({
    consumables1 %>%
      filter(Year %in% input$Yearos)
  })
  
  # output$consumab <- DT::renderDT(
  #   consume(), # data
  #   class = "display nowrap compact", 
  #   options = list(pageLength = 15, lengthChange = FALSE),
  #   colnames = NULL,# style
  #   filter = "none",
  #   #options = list(scrollX = FALSE),# location of column filters
  #   rownames = FALSE,
  #   selection = 'none', 
  # )
  output$consumab <- renderFormattable({
    risk <- formattable(consume(), list(
      # Rating = formatter("span",
      #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
      #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
      #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  
  #users
  filtered_users<- reactive({
    singleit %>%
      #as.data.frame() %>%
      filter(Year == input$Yearos)%>%
      magrittr::use_series(users_surpoted ) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_users(),
               {
                 output$progressBox8 <- renderInfoBox({
                   infoBox(
                     "Number of users",  format(filtered_users(), big.mark = ","), icon = icon("users-cog"),
                     color = "green"
                   )
                 })
               })
  
  #issues
  filtered_issues<- reactive({
    singleit %>%
      #as.data.frame() %>%
      filter(Year == input$Yearos)%>%
      magrittr::use_series(issues) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_issues(),
               {
                 output$approvalBox8b <- renderInfoBox({
                   infoBox(
                     "Number of issues raised",  format(filtered_issues(), big.mark = ","), icon = icon("list-ol"),
                     color = "green"
                   )
                 })
               })
  #consumables
  filtered_consum<- reactive({
    singleit %>%
      #as.data.frame() %>%
      filter(Year == input$Yearos)%>%
      magrittr::use_series(consumables) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_consum(),
               {
                 output$approvalBox8c <- renderInfoBox({
                   infoBox(
                     "Cost of consumables",  format(filtered_consum(), big.mark = ","), icon = icon("hand-holding-usd"),
                     color = "green"
                   )
                 })
               })
  
  # # downtimes
  # filtered_dwn<- reactive({
  #   singleit %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearos, Month ==input$variable)%>%
  #     magrittr::use_series(downtimes) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_dwn(),
  #              {
  #                output$gaugedwn = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_dwn(),
  #                                       min = 0, max = 2,symbol = 'hrs', gaugeSectors(
  #                                         danger = c(0.6, 0.9), warning = c(1, 1.5), success = c(1.6,2)))
  #                  
  #                })
  #              })
  # turnaround
  # filtered_tn<- reactive({
  #   singleit %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearos, Month ==input$variable)%>%
  #     magrittr::use_series(turnaround) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_tn(),
  #              {
  #                output$gaugetn = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_tn(),
  #                                       min = 0, max = 24,symbol = 'hrs',   flexdashboard::gaugeSectors(
  #                                         danger = c(0, 8), warning = c(9, 17), success = c(18,24)))
  #                  
  #                })
  #              })
  # observeEvent(filtered_tn(),
  #              {
  #                
  #                renderGauge(div_id = "it2gauge",rate = filtered_tn(), gauge_name = ".",
  #                            theme = "london", 
  #                            show.tools = FALSE,
  #                            animation = TRUE,
  #                            running_in_shiny = TRUE)
  #                  
  #                })
  #              
  # itgg <- reactive({
  #   if(!input$variable == "All"){
  #     usertraining %>% 
  #       filter(variable == input$variable & Year == input$Yearos) %>%
  #       group_by(training) %>%
  #       summarise(mean_active = sum(value))
  #   }else{
  #     usertraining %>% 
  #       filter(Year == input$Yearos) %>%
  #       group_by(training) %>%
  #       summarise(mean_active = sum(value))
  #   }
  #   #as.data.frame(tezt2)
  #   #names(tezt2)<- c("partner", "counts")
  # })
  
  utrainfilt<- reactive({ 
    utrain3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearos)%>%
      column_to_rownames(var = "variable")%>%
      dplyr::select("New users' training",  "Refresher training")
    
  })
  
  observeEvent(utrainfilt(),
               {
                 
                 renderLineChart(div_id = "filt2", grid_left = '1%', stack_plot =TRUE,theme = "shine",
                                 data = utrainfilt())
                 # renderBarChart(div_id = "filt2", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                 #                
                 #                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                 #                show.legend = FALSE, show.tools = TRUE,
                 #                font.size.legend = 12,
                 #                font.size.axis.x = 12, font.size.axis.y = 12,
                 #                axis.x.name = NULL, axis.y.name = NULL,
                 #                rotate.axis.x = 0, rotate.axis.y = 0,
                 #                bar.max.width = 30,
                 #                animation = TRUE,
                 #                hyperlinks = NULL,
                 #                data = utrainfilt())
                 
                 
               })
  # 
  # itgg <- reactive({
  #   usertraining %>%
  #   as.data.frame() %>%  
  #   filter(Year == input$Year & variable == input$variable )%>%
  #   column_to_rownames(var = "training")
  #   
  #   # %>%
  #   # select(Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, All)
  #   # # set_colnames(c("First Aid", "Fire", "Health", "Safety"))
  #   
  # })
  # 
  # observeEvent(itgg(),
  #              {
  #                renderBarChart(div_id = "itgg2", grid_left = '1%', direction = "horizontal",stack_plot =TRUE,
  #                               data = itgg())
  #              })
  output$itgg <- renderPlotly({
    
    
    p <-
      ggplot(data = itgg(), aes( y=mean_active, x=training)) + 
      geom_bar(position="stack", stat="identity")
    
    
    #   ggplot(data = itgg(), mapping = aes(x = reorder(training, mean_active), mean_active))+
    #   geom_bar(position="stack",stat = "identity") +
    # 
    #   geom_text(aes(label = mean_active), vjust = -0.3) +
    #   theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
    # 
    #   coord_flip()+
    #   xlab("") +
    #   ylab("")
    # 
    # #theme_pubclean()
    
    
    
    ggplotly(p)
    p
  })
  
  #renderGauge(div_id = "itgauge",rate = 45, gauge_name = "turn around time of the suppliers")
  #renderGauge(div_id = "itgauge",rate = 72, gauge_name = "turn around time of the suppliers, based on a rating. ")
  
  
  ####OSH@###########################################################################
  output$progressBox9a <- renderInfoBox({
    infoBox(
      "Progress", paste0(25 + input$count, "%"), icon = icon("list"),
      color = "purple", fill = TRUE
    )
  })
  output$approvalBox9b <- renderInfoBox({
    infoBox(
      "Approval", "80%", icon = icon("thumbs-up", lib = "glyphicon"),
      color = "yellow", fill = TRUE
    )
  })
  output$progressBox9c <- renderInfoBox({
    infoBox(
      "Progress", paste0(25 + input$count, "%"), icon = icon("list"),
      color = "purple", fill = TRUE
    )
  })
  output$approvalBox9d <- renderInfoBox({
    infoBox(
      "Approval", "80%", icon = icon("thumbs-up", lib = "glyphicon"),
      color = "yellow", fill = TRUE
    )
  })
  output$progressBox9e <- renderInfoBox({
    infoBox(
      "Progress", paste0(25 + input$count, "%"), icon = icon("list"),
      color = "purple", fill = TRUE
    )
  })
  output$approvalBox9f <- renderInfoBox({
    infoBox(
      "Approval", "80%", icon = icon("thumbs-up", lib = "glyphicon"),
      color = "yellow", fill = TRUE
    )
  })
  
  ###osh charts
  filtered_injury<- reactive({
    
    injury2 %>%
      filter(Location == input$Location & Year == input$Yearos) %>%
      group_by(Cause) %>%
      summarise(mean_active = sum(value))
    
  })
  
  
  output$injury <- renderPlotly ({
    
    p5 <-plot_ly(filtered_injury()) %>%
      add_pie(labels=filtered_injury()$Cause,values=filtered_injury()$mean_active,hole=0.6)
    
    ggplotly(p5)
    
  })
  
  filtered_risks<- reactive({
    risks %>% 
      filter(Department == input$dept & Year==input$Yearos) 
  })
  
  output$risk <- renderFormattable({
    risk <- formattable(filtered_risks(), list(
      Rating = formatter("span",
                         style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
                         x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
                                      ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
    ))
    
  })
  filtered_oshtrain<- reactive({ 
    oshtrain %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearos)%>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(First_Aid, Fire, Health, Safety)%>%
      set_colnames(c("First Aid", "Fire", "Health", "Safety"))
  })
  
  observeEvent(filtered_oshtrain(),
               {
                 renderBarChart(div_id = "oshtrain", direction = "vertical", grid_left = '1%', stack_plot =TRUE,show.legend = FALSE,
                                data = filtered_oshtrain())
               })
  
  ###warehouse charts
  #number of supplies
  filt_supplies<- reactive({
    num_supplies4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(No_of_suppliers)
    
    
  })
  
  observeEvent(filt_supplies(),
               {
                 renderLineChart(div_id = "numsupplies", grid_left = '1%', stack_plot =FALSE,theme = "vintage",show.legend = FALSE,
                                 data = filt_supplies())
               })
  
  #number of items
  filt_itms<- reactive({
    num_supplies4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Items_Received )
    
    
  })
  
  observeEvent(filt_itms(),
               {
                 
                 renderBarChart(div_id = "numitems", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = filt_itms())
               }) 
  
  #Average_supplier_delivery
  filt_avgsup<- reactive({
    num_supplies4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Average_supplier_delivery )
    
    
  })
  
  observeEvent(filt_avgsup(),
               {
                 
                 renderBarChart(div_id = "avgsupplier", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = filt_avgsup())
                 
               }) 
  
  
  #Quantity received
  quant_filt<- reactive({
    num_supplies4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Quantity_Received )
    
    
  })
  
  observeEvent(quant_filt(),
               {
                 renderLineChart(div_id = "quantreceived", grid_left = '1%', stack_plot =TRUE,theme = "vintage",show.legend = FALSE,
                                 data = quant_filt())
               }) 
  
  #No_of_orders
  order_filt<- reactive({
    order_prep4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(No_of_orders)
    
    
  })
  
  observeEvent(order_filt(),
               {
                 renderLineChart(div_id = "numorders", grid_left = '1%', stack_plot =TRUE,theme = "vintage",show.legend = FALSE,
                                 data = order_filt())
               }) 
  #average time to process
  order_time<- reactive({
    order_prep4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(avgtime_order)
    
    
  })
  
  observeEvent(order_time(),
               {
                 
                 
                 renderBarChart(div_id = "avgtimeorder", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = order_time())
               }) 
  
  #cost of maintenance
  equip<- reactive({
    equipment4 %>%
      filter(Year==input$Year_wh) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Costofmaintenance)%>%
      set_colnames(c("Cost of maintenance"))
    
    
  })
  
  observeEvent(equip(),
               {
                 
                 renderBarChart(div_id = "costmaintain", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = NULL,
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = equip())
               }) 
  
  # #ORDER ACCURACY
  # output$gauge = flexdashboard::renderGauge({
  #   flexdashboard::gauge(input$value,
  #                        min = 0,
  #                        max = 5,
  #                        sectors = gaugeSectors(success = c(0.5, 1),
  #                                               warning = c(0.3, 0.5),
  #                                               danger = c(0, 0.3)))
  # })
  
  ####################################################################################
  #   
  #   output$progressBox10 <- renderInfoBox({
  #     infoBox(
  #       "Progress", paste0(25 + input$count, "%"), icon = icon("list"),
  #       color = "purple", fill = TRUE
  #     )
  #   })
  #   output$approvalBox10 <- renderInfoBox({
  #     infoBox(
  #       "Approval", "80%", icon = icon("thumbs-up", lib = "glyphicon"),
  #       color = "red", fill = TRUE
  #     )
  #   })
  #   
  #   
  #   
  # 
  #  
  #   output$dummy <- renderPlot ({
  #   dm <- ggplot(dummy, aes(fill = group, ymax = percentage, ymin = 0, xmax = 2, xmin = 1)) +
  #     geom_rect(aes(ymax=1, ymin=0, xmax=2, xmin=1), fill ="#ece8bd") +
  #     geom_rect() + 
  #     coord_polar(theta = "y",start=-pi/2) + xlim(c(0, 2)) + ylim(c(0,2)) +
  #     geom_text(aes(x = 0, y = 0, label = label, colour=group), size=6.5, family="Poppins SemiBold") +
  #     geom_text(aes(x=1.5, y=1.5, label=title), family="Poppins Light", size=4.2) + 
  #     facet_wrap(~title, ncol = 5) +
  #     theme_void() +
  #     scale_fill_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #     scale_colour_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #     theme(strip.background = element_blank(),
  #           strip.text.x = element_blank()) +
  #     guides(fill=FALSE) +
  #     guides(colour=FALSE)
  #   dm
  # })
  #   
  #   output$val <- renderPlot ({
  #     dm <- ggplot(val, aes(fill = group, ymax = number, ymin = 0, xmax = 2, xmin = 1)) +
  #       geom_rect(aes(ymax=1, ymin=0, xmax=2, xmin=1), fill ="#ece8bd") +
  #       geom_rect() + 
  #       coord_polar(theta = "y",start=-pi/2) + xlim(c(0, 2)) + ylim(c(0,2)) +
  #       geom_text(aes(x = 0, y = 0, label = label, colour=group), size=6.5, family="Poppins SemiBold") +
  #       geom_text(aes(x=1.5, y=1.5, label=title), family="Poppins Light", size=4.2) + 
  #       facet_wrap(~title, ncol = 5) +
  #       theme_void() +
  #       scale_fill_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #       scale_colour_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #       theme(strip.background = element_blank(),
  #             strip.text.x = element_blank()) +
  #       guides(fill=FALSE) +
  #       guides(colour=FALSE)
  #     dm
  #   })
  #   
  #   output$leave <- renderPlotly ({
  #     dm <- ggplot(leave, aes(fill = group, ymax = percentage, ymin = 0, xmax = 2, xmin = 1)) +
  #       geom_rect(aes(ymax=1, ymin=0, xmax=2, xmin=1), fill ="#ece8bd") +
  #       geom_rect() + 
  #       coord_polar(theta = "y",start=-pi/2) + xlim(c(0, 2)) + ylim(c(0,2)) +
  #       geom_text(aes(x = 0, y = 0, label = label, colour=group), size=6.5, family="Poppins SemiBold") +
  #       geom_text(aes(x=1.5, y=1.5, label=title), family="Poppins Light", size=4.2) + 
  #       facet_wrap(~title, ncol = 5) +
  #       theme_void() +
  #       scale_fill_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #       scale_colour_manual(values = c("red"="#C9146C", "orange"="#DA9112", "green"="#129188")) +
  #       theme(strip.background = element_blank(),
  #             strip.text.x = element_blank()) +
  #       guides(fill=FALSE) +
  #       guides(colour=FALSE)
  #     ggplotly(dm)
  #     dm
  #   })
  #   
  #   output$fig <- renderPlotly ({
  #   
  #   fig <- plot_ly(
  #     domain = list(x = c(0, 1), y = c(0, 1)),
  #     value = 8,
  #     title = list(text = "Turnaround time"),
  #     type = "indicator",
  #     mode = "gauge+number+delta",
  #     delta = list(reference = 3),
  #     gauge = list(
  #       axis =list(range = list(NULL, 10)),
  #       steps = list(
  #         list(range = c(0, 8), color = "lightgray"),
  #         list(range = c(4, 6), color = "gray")),
  #       threshold = list(
  #         line = list(color = "red", width = 4),
  #         thickness = 0.75,
  #         value = 7))) 
  #   fig <- fig %>%
  #     layout(margin = list(l=20,r=30))
  #   
  #   ggplotly(fig)
  #   fig
  #   })
  #   
  # #   output$fig2 <- renderPlotly ({
  # #   fig2 <- plot_ly(
  # #     domain = list(x = c(0, 1), y = c(0, 1)),
  # #     value = 70,
  # #     title = list(text = h4("Turnaround time (hours)")),
  # #     type = "indicator",
  # #     mode = "gauge+number+delta",
  # #     delta = list(reference = 3),
  # #     gauge = list(
  # #       axis =list(range = list(NULL, 10)),
  # #       steps = list(
  # #         list(range = c(0, 50), color = "lightgray"),
  # #         list(range = c(40, 60), color = "gray")),
  # #       threshold = list(
  # #         line = list(color = "red", width = 4),
  # #         thickness = 0.75,
  # #         value = 70))) 
  # #   fig2 <- fig2 %>%
  # #     layout(margin = list(l=20,r=30))
  # #   
  # #   ggplotly(fig2)
  # #   fig2
  # # })
  # 
  #   # reactive that generates a random value for the gauge
  #   # value = reactive({
  #   #   invalidateLater(1000)
  #   #   round(runif(1,0,100),2)
  #   # })
  #   # 
  #   # # example use of the automatically generated render function
  #   # output$gauge1 <- renderC3Gauge({ 
  #   #   # C3Gauge widget
  #   #   C3Gauge(value())
  #   # })
  # #   africa <- dplyr::filter(world, region_un=='Africa') %>%
  # #     dplyr::left_join(internet_usage %>% dplyr::select(
  # #       `Country Code`, `2015 [YR2015]`
  # #     ) %>% dplyr::rename(iso_a3=`Country Code`, internet.usage.2015=`2015 [YR2015]`),
  # #     by = 'iso_a3') %>%
  # #     st_transform(crs="+proj=laea +lon_0=18.984375")
  # # #
  # #   africa.centers <- st_centroid(africa)
  # # #
  # # africa.spdf <- methods::as(africa, 'Spatial')
  # #    africa.spdf@data$id <- row.names(africa.spdf@data)
  # # #
  # #    africa.tidy <- broom::tidy(africa.spdf)
  # # #
  # #   africa.tidy <- dplyr::left_join(africa.tidy, africa.spdf@data, by='id')
  # # #
  # #    output$africag <- renderggiraph({
  # #     africag <- ggplot(africa.tidy) +
  # #     geom_polygon_interactive(
  # #       color='black',
  # #       aes(long, lat, group=group, fill=internet.usage.2015,
  # #           tooltip=sprintf("%s<br/>%s",iso_a3,internet.usage.2015))) +
  # #     hrbrthemes::theme_ipsum() +
  # #     colormap::scale_fill_colormap(
  # #       colormap=colormap::colormaps$viridis, reverse = T) +
  # #     labs(title='Where we work'
  # #          #caption='Source: World Bank Open Data.'
  # #          )
  # # #
  # #     africag <- ggiraph(code=print(africag))
  # #  africag
  # # #
  # #    })
  # 
  #    output$ff <- renderPlotly({
  #    ff <- plot_ly(data2020, main = "Most Populous US Cities in 2019 (in millions)", labels = ~Gender, values = ~ values, type = "pie", domain = list(x = c(0, 0.5), y = c(0, 1))) %>%
  #      add_trace(data = data2021, labels = ~Gender, values = ~ values, type = "pie", domain = list(x = c(0.5, 1), y = c(0, 1)))
  #    ff
  #    })
  #    
  filtered_audits<- reactive({
    audits %>%
      as.data.frame() %>%
      filter(Year == input$Yearos) %>%
      # `row.names<-`(c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "All")) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(extaudit,intaudit )%>%
      set_colnames(c("External audit", "Internal audit"))
  })
  
  observeEvent(filtered_audits(),
               {
                 
                 renderLineChart(div_id = "auditbar",
                                 data = filtered_audits())
               })
  
  # observeEvent(filtered_orders(),
  #              {
  #                renderPieChart(div_id = "p_freq",
  #                               data = filtered_orders())
  # })
  
  # renderLineChart(div_id = "line1",
  #                 data = hrleave2)
  
  
  
  
  ###########QA CHARTS###############################
  
  
  #partner complaints
  # output$naturecompl <- renderUI({
  #   selectInput("nature", 
  #               label = "Nature of complaint", 
  #               choices = as.list(unique(partcompl3$Nature_of_complaint)))
  # })
  
  gmpaud<- reactive({ 
    gmpaudits3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearqa)%>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Total)
  })
  
  observeEvent(gmpaud(),
               {
                 renderBarChart(div_id = "gmpaud_bar", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = gmpaud())
               })
  
  glpaud<- reactive({ 
    glpaudits3 %>% 
      as.data.frame() %>%  
      filter(Year == input$Yearqa)%>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Total)
  })
  
  observeEvent(glpaud(),
               {
                 renderBarChart(div_id = "glpaud_bar", grid_left = '1%', direction = "vertical",stack_plot =FALSE,
                                theme = "vintage", 
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                
                                data = glpaud())
               })
  
  
  filtered_partcompl3<- reactive({ 
    partcompl3 %>% 
      as.data.frame() %>%
      #filter(Year == 2020,  Nature_of_complaint=="Order cancellation")%>%
      filter(Year == input$Yearqa, Nature_of_complaint==input$nature)%>%
      column_to_rownames(var = "Organization")%>%
      #%>%set_colnames(-c( "Nature_of_complaint","Date_of_opening","Date_of_closure" ))
      dplyr::select(-c(Year, Nature_of_complaint, Date_of_opening,Date_of_closure))
    
  })
  
  observeEvent(filtered_partcompl3(),
               {
                 renderBarChart(div_id = "partner_compl", grid_left = '1%', direction = "horizontal",
                                stack_plot =TRUE,
                                theme = "vintage", 
                                show.legend = FALSE, show.tools = TRUE,
                                # grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                # show.legend = FALSE, show.tools = TRUE,
                                # font.size.legend = 12,
                                # font.size.axis.x = 12, font.size.axis.y = 12,
                                # axis.x.name = NULL, 
                                # rotate.axis.x = 0, rotate.axis.y = 0,
                                # bar.max.width = 15,
                                # animation = TRUE,
                                # hyperlinks = NULL,
                                data = filtered_partcompl3())
               })
  
  
  
  #supplier complaints
  
  df_supcompl3<- reactive({ 
    supcompl3 %>% 
      as.data.frame() %>%
      #filter(Year == 2020,  Nature_of_complaint=="Leaking /Broken Item/Damaged")%>%
      filter(Year == input$Yearqa, Nature_of_complaint==input$nature2)%>%
      column_to_rownames(var = "Organization")%>%
      #%>%set_colnames(-c( "Nature_of_complaint","Date_of_opening","Date_of_closure" ))
      dplyr::select(-c(Year, Nature_of_complaint, Date_of_opening,Date_of_closure))
    
  })
  
  observeEvent(df_supcompl3(),
               {
                 renderBarChart(div_id = "sup_compl", grid_left = '15%', direction = "horizontal",
                                stack_plot =TRUE,
                                theme = "vintage", 
                                show.legend = FALSE, show.tools = TRUE,
                                # grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                # show.legend = FALSE, show.tools = TRUE,
                                # font.size.legend = 12,
                                # font.size.axis.x = 12, font.size.axis.y = 12,
                                # axis.x.name = NULL, 
                                # rotate.axis.x = 0, rotate.axis.y = 0,
                                # bar.max.width = 15,
                                # animation = TRUE,
                                # hyperlinks = NULL,
                                data = df_supcompl3())
               })
  
  filtered_itm<- reactive({
    rr <- items2 %>%
      #as.data.frame() %>%
      #filter(Year == input$Year)%>%
      magrittr::use_series(Total) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_itm(),
               {
                 output$itm <- renderInfoBox({
                   infoBox(
                     "No. of available items", formatC(filtered_itm(), big.mark = ",", format = "f", digits = 0), icon = icon("list"),
                     color = "green", fill =TRUE
                   )
                 })
               })
  
  # filtered_supcompl3<- reactive({ 
  #   supcompl5 %>% 
  #     as.data.frame() %>%
  #     filter(Year == input$Year, Nature_of_complaint==input$nature)
  #   
  # })
  # 
  # 
  # output$mgrt <- renderPlotly({
  #   p <-
  #     
  #     ggplot(data = filtered_supcompl3(), mapping = aes(x = variable, y = value, color = Nature_of_complaint))
  #    
  #   ggplotly(p)
  #   p
  # })
  # 
  # observeEvent(filtered_supcompl3(),
  #              {
  #                
  #                renderLineChart(div_id = "supplier_compl", show.legend = FALSE,
  #                                
  #                                data = filtered_supcompl3())
  #              })
  
  
  # observeEvent(filtered_supcompl3(),
  #              {
  #                plot_ly(x = ~variable, y = ~n, color = ~Organization)
  #              })
  # 
  #supplier increase or decrease
  supinc_filt<- reactive({
    supinc3 %>%
      as.data.frame() %>%
      filter(Year == input$Yearqa) %>%
      set_colnames(c("Year", "Month","Supplier_Count")) %>%
      
      # `row.names<-`(c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "All")) %>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(Supplier_Count)
  })
  
  observeEvent(supinc_filt(),
               {
                 
                 renderLineChart(div_id = "supplier_inc", show.legend = FALSE,theme = "vintage", stack_plot = TRUE,
                                 
                                 data = supinc_filt())
               })
  
  #qc schedule 
  qc_sched <- reactive({
    qc_schedule3 %>%
      filter(Year %in% input$Yearqa)%>%
      magrittr::use_series(Completed) %>% magrittr::extract(1)
    #select(dept, fulltimestaff)%>%
  })
  
  # qc_total <- reactive({
  #   qc_schedule3 %>%
  #     filter(Year %in% input$Year)%>%
  #     magrittr::use_series(Total) %>% magrittr::extract(1)
  #   #select(dept, fulltimestaff)%>%
  # })
  # 
  # observeEvent(qc_sched(),
  #              {
  #                
  #                renderGauge(div_id = "gaugeqa",  gauge_name = "QC on schedule", 
  #                                
  #                                rate = qc_sched())
  #              })
  
  
  
  output$qc <- renderPlotly({
    
    fig <- plot_ly(
      type = "indicator",
      mode = "gauge+number+delta",
      value = qc_sched(),
      #title = list(text = "Completed QC on schedule", font = list(size = 10)),
      delta = list(reference = 69, increasing = list(color = "RebeccaPurple")),
      gauge = list(
        axis = list(range = list(NULL, 69), tickwidth = 1, tickcolor = "darkgreen"),
        bar = list(color = "green"),
        bgcolor = "white",
        borderwidth = 2,
        bordercolor = "gray",
        steps = list(
          list(range = c(0, 35), color = "white"),
          list(range = c(36, 100), color = "white")),
        threshold = list(
          line = list(color = "black", width = 4),
          thickness = 0.75,
          value = qc_sched()))) 
    fig <- fig %>%
      layout(
        margin = list(l=20,r=30),
        #paper_bgcolor = "lavender",
        font = list(color = "olive", family = "Arial"))
    
    fig
  })
  
  # # resultqc
  # 
  #    observeEvent(qc_sched(), qc_total(),
  #              {
  #                output$gaugeqa5 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(qc_sched(),
  #                                       min = 0, max = qc_total(), symbol = '%', gaugeSectors(
  #                                         warning = c(0, qc_total()/4), success = c(qc_total()/2,qc_total())))
  #                  
  #                })
  #              })
  # 
  
  #internal audit
  
  int_audit <- reactive({
    intaudit3 %>%
      filter(Year %in% input$Yearqa & status %in% input$status)%>%
      summarise(Scope)
  })
  
  output$internaud <- DT::renderDT(
    int_audit(), # data
    class = "display nowrap compact", 
    options = list(pageLength = 15, lengthChange = FALSE),
    colnames = NULL,# style
    filter = "none",
    #options = list(scrollX = FALSE),# location of column filters
    rownames = FALSE,
    selection = 'none', 
  )
  # output$intauditstatus <- renderFormattable({
  #   wh2 <- formattable(int_audit(), list(
  #     # Rating = formatter("span",
  #     #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
  #     #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
  #     #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
  #   ))
  # })
  
  #internal audit
  
  ext_audit <- reactive({
    extaudit5 %>%
      #Year %in% input$Year 
      filter(Completed2 %in% input$statusext)%>%
      summarise(Auditee_process)
  })
  
  output$statusext <- DT::renderDT(
    ext_audit(), # data
    class = "display nowrap compact", 
    options = list(pageLength = 15, lengthChange = FALSE),
    colnames = NULL,# style
    filter = "none",
    #options = list(scrollX = FALSE),# location of column filters
    rownames = FALSE,
    selection = 'none',
    
  )
  
  observeEvent(ext_audit(),{
    write.csv(ext_audit(), "tables.csv")
  })
  #download tables
  output$downloadstts <- downloadHandler(
    filename <- function() {
      paste(paste("tables"), ".csv", sep="")
    },
    
    content <- function(file) {
      file.copy("tables.csv", file)
    },
    contentType = "application/csv"
  )
  
  # output$extauditstatus <- renderFormattable({
  #   whext2 <- formattable(ext_audit(), list(
  #     # Rating = formatter("span",
  #     #                    style = x ~ style(color = ifelse(x == "Low", "green", ifelse(x == "Medium", "blue", "red"))),
  #     #                    x ~ icontext(ifelse(x == "Low", "ok", ifelse(x == "Medium", "remove", NA)),
  #     #                                 ifelse(x=="Low", "Low", ifelse(x == "Medium", "Medium", "High"))))
  #   ))
  # })
  
  # #extaudit drill
  # output$p <- renderPlot(ggplot(extaudit5,aes(x=factor(carb),y=value))+
  #                          geom_bar(stat="summary",fun.y="mean"))
  # output$info <- renderText(
  #   paste0("x=", input$plot_click$x, "\n",
  #          "y=", input$plot_click$y))
  # 
  # output$table <- renderTable({
  #   ##magic happens here##
  #   output$table <- renderTable({
  #     carb <- unique(extaudit5$carb)
  #     carb <- carb[order(carb)]
  #     x <- carb[round(input$plot_click$x)]
  #     extaudit5[extaudit5$carb == x,]
  #   })
  #   
  # })
  
  # filtered_auditext<- reactive({
  #   
  #   extaudit6 %>% 
  #     #filter(Year == input$Year) %>%
  #     set_colnames(c("name", "value"))
  # })
  # 
  # 
  # observeEvent(filtered_auditext(),
  #              {
  #                renderPieChart(div_id = "auditextpie",
  #                               theme = 'vintage', 
  #                               show.label = TRUE,
  #                               show.legend = FALSE, show.tools = TRUE,
  #                               font.size.legend= 12,
  #                               animation = TRUE,
  #                               hyperlinks = NULL,
  #                               data = filtered_auditext())
  #              })
  
  # conform_filt<- reactive({
  #   conform3 %>%
  #     as.data.frame() %>%
  #     filter(Year==input$Yearconf, Source==input$Source)
  # 
  # })
  # 
  # 
  # observeEvent(conform_filt(),
  #              {
  #                renderBarChart(div_id = "confbar", grid_left = '1%', direction = "vertical",stack_plot =TRUE,
  #                               theme = "vintage",
  #                               grid_right ="5%", grid_top="20%", grid_bottom="4%",
  #                               show.legend = FALSE, show.tools = TRUE,
  #                               font.size.legend = 12,
  #                               font.size.axis.x = 12, font.size.axis.y = 12,
  #                               axis.x.name = NULL,
  #                               rotate.axis.x = 0, rotate.axis.y = 0,
  #                               bar.max.width = 30,
  #                               animation = TRUE,
  #                               hyperlinks = NULL,
  #                               data = conform_filt())
  #              })
  
  # critical
  filtered_critical<- reactive({
    breakdown4 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearqa)%>%
      magrittr::use_series(Critical) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_critical(),
               {
                 output$critical <- renderInfoBox({
                   infoBox(
                     "Critical", filtered_critical(), icon = icon("bolt"),
                     color = "red",fill=TRUE
                   )
                 })
               })
  
  # major
  filtered_major<- reactive({
    breakdown4 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearqa)%>%
      magrittr::use_series(Major) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_major(),
               {
                 output$major <- renderInfoBox({
                   infoBox(
                     "Major", filtered_major(), icon = icon("sort-up"),
                     color = "orange", fill=TRUE
                   )
                 })
               })
  
  # minor
  filtered_minor<- reactive({
    breakdown4 %>%
      #as.data.frame() %>%
      filter(Year == input$Yearqa)%>%
      magrittr::use_series(minor) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_minor(),
               {
                 output$minor <- renderInfoBox({
                   infoBox(
                     "Minor", filtered_minor(), icon = icon("sort-desc"), 
                     color = "olive", fill=TRUE
                   )
                 })
               })
  # 
  # # major
  # filtered_major<- reactive({
  #   conform4 %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Year, Source == "PO", Nature =="Critical", variable=="closed")%>%
  #     magrittr::use_series(value) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_major(),
  #              {
  #                output$major <- renderInfoBox({
  #                  infoBox(
  #                    "Closed Critical Major non-conformities", filtered_major(), icon = icon("sort-up"),
  #                    color = "red"
  #                  )
  #                })
  #              })
  
  #Conformities
  
  filtered_confo<- reactive({ 
    conform3 %>% 
      as.data.frame() %>%  
      filter(Year == 2019, Source =="PO")%>%
      column_to_rownames(var = "Nature")%>%
      dplyr::select(closed, new)
    
  })
  
  # output$confo <- renderPlotly ({
  #   fig <- plot_ly(filtered_confo(), labels = ~closed, values = ~new, type = 'pie')
  #   fig <- fig %>% layout(
  #     xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
  #     yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
  #   
  #   fig
  #   
  # })
  # 
  observeEvent(filtered_confo(),
               {
                 renderBarChart(
                   
                   div_id = "conformities", grid_left = '15%', direction = "horizontal",
                   stack_plot =TRUE,
                   theme = "vintage", 
                   show.legend = FALSE, show.tools = TRUE,
                   
                   data = filtered_confo())
               })
  
  
  #risk analysis
  
  filtered_riskcat<- reactive({ 
    riskcat2 %>% 
      as.data.frame() %>%  
      filter(Year == 2018, Risk ==input$risk)%>%
      column_to_rownames(var = "Month")%>%
      dplyr::select(infrastructure_assetmanagement, performance_financial, Productandservicedelivery)%>%
      set_colnames(c("Infrastructure/asset management", "Performance/financial", "Product and service delivery"))
  })
  
  observeEvent(filtered_riskcat(),
               {
                 renderBarChart(div_id = "risk_cat", grid_left = '1%', theme = "vintage",direction = "horizontal",stack_plot =TRUE,
                                
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, 
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                
                                bar.max.width = 50,
                                animation = TRUE,
                                hyperlinks = NULL,
                                data = filtered_riskcat())
               }) 
  
  
  # # minor
  # filtered_minor<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == 2020)%>%
  #     magrittr::use_series(minor) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_minor(),
  #              {
  #                output$progressBoxqa2 <- renderInfoBox({
  #                  infoBox(
  #                    "Number of minor non-conformities",  format(filtered_minor(), big.mark = ","), icon = icon("sort-desc"),
  #                    color = "yellow"
  #                  )
  #                })
  #              })
  # 
  # # critical
  # filtered_critical<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearqa, Month ==input$variable)%>%
  #     magrittr::use_series(critical) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_critical(),
  #              {
  #                output$progressBoxqa3 <- renderInfoBox({
  #                  infoBox(
  #                    "Number of critical non-conformities",  format(filtered_critical(), big.mark = ","), icon = icon("thermometer-quarter"),
  #                    color = "purple"
  #                  )
  #                })
  #              })
  # 
  # 
  # # report
  # filtered_report<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearqa, Month ==input$variable)%>%
  #     magrittr::use_series(report) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_report(),
  #              {
  #                output$gaugeqa1 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_report(),
  #                                       min = 0, max = 12,symbol = 'mths', gaugeSectors(
  #                                         danger = c(0, 4), warning = c(5, 8), success = c(9,12)))
  #                  
  #                })
  #              })  
  # # timemajor
  # filtered_timem<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearqa, Month ==input$variable)%>%
  #     magrittr::use_series(timemajor) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_timem(),
  #              {
  #                output$gaugeqa2 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_timem(),
  #                                       min = 0, max = 3, symbol = 'mths',gaugeSectors(
  #                                         danger = c(0, 1), warning = c(2, 2), success = c(3,3)))
  #                  
  #                })
  #              }) 
  # # timeminor
  # filtered_timinor<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearqa, Month ==input$variable)%>%
  #     magrittr::use_series(timeminor) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_timem(),
  #              {
  #                output$gaugeqa3 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_timinor(),
  #                                       min = 0, max = 6,symbol = 'mths', gaugeSectors(
  #                                         danger = c(0, 2), warning = c(3, 4), success = c(5,6)))
  #                  
  #                })
  #              })
  # # timecritical
  # filtered_timcrit<- reactive({
  #   singleqa %>%
  #     #as.data.frame() %>%
  #     filter(Year == input$Yearqa, Month ==input$variable)%>%
  #     magrittr::use_series(timecritical) %>% magrittr::extract(1)
  # })
  # 
  # observeEvent(filtered_timem(),
  #              {
  #                output$gaugeqa4 = flexdashboard::renderGauge({
  #                  flexdashboard::gauge(filtered_timcrit(),
  #                                       min = 0, max = 4, symbol = 'wks',gaugeSectors(
  #                                         danger = c(0, 1), warning = c(2, 3), success = c(4,4)))
  #                  
  #                })
  #              })
  # 
  # 
  # ##internalaudit
  # filtered_intaud<- reactive({
  #   
  #   intext2 %>%
  #     filter(audit == input$audit & variable == input$variable  & Year == input$Yearqa) %>%
  #     group_by(type) %>%
  #     summarise(mean_active = sum(value))
  #   
  # })
  # 
  # 
  # output$intaud <- renderPlotly ({
  #   
  #   p5 <-plot_ly(filtered_intaud()) %>%
  #     add_pie(labels=filtered_intaud()$type,values=filtered_intaud()$mean_active,hole=0.6)
  #   
  #   ggplotly(p5)
  #   
  # })
  
  
  #finance
  #Finance charts
  # major
  filtered_results<- reactive({
    singlefin %>%
      #as.data.frame() %>%
      filter(Year == input$Yearfin)%>%
      magrittr::use_series(overall_results) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_results(),
               {
                 output$finBox1 <- renderInfoBox({
                   infoBox(
                     "Overall results for the period", formatC(filtered_results(), big.mark = ",", format = "f", digits = 0), icon = icon("line-chart"),
                     color = "aqua", fill =TRUE
                   )
                 })
               })
  
  filtered_inc<- reactive({
    rr <- singlefin %>%
      #as.data.frame() %>%
      filter(Year == input$Yearfin)%>%
      magrittr::use_series(average_income) %>% magrittr::extract(1)
  })
  
  observeEvent(filtered_inc(),
               {
                 output$finBox2 <- renderInfoBox({
                   infoBox(
                     "Average income", formatC(filtered_inc(), big.mark = ",", format = "f", digits = 0), icon = icon("hand-holding-usd"),
                     color = "green", fill =TRUE
                   )
                 })
               })
  curratio<- reactive({
    singlefin %>%
      #as.data.frame() %>%
      filter(Year == input$Yearfin)%>%
      magrittr::use_series(current_ratio) %>% magrittr::extract(1)
  })
  
  observeEvent(curratio(),
               {
                 output$finBox3 <- renderInfoBox({
                   infoBox(
                     "Current ratio", curratio(), icon = icon("percent"),
                     color = "yellow", fill =TRUE
                   )
                 })
               })
  
  
  # filt_income<- reactive({
  #   income4 %>%
  #     as.data.frame() %>%
  #     filter(Year == input$Year) %>%
  #     column_to_rownames(var = "Month")%>%
  #     #set_colnames(income4, c("Year", "Month", "Net income", "Operating expenses", "Results"))
  #     select( `Net Income`, `Operating Expenses`)
  #     
  # })
  
  filt_income <- reactive({
    
    income5 %>%
      as.data.frame() %>%
      filter(Year == input$Yearfin) %>%
      dplyr::select( Month, Net2, Operating2)%>%
      set_colnames(c("Month", "Net income", "Operating expenses"))%>%
      column_to_rownames(var = "Month")
    #set_colnames(income4, c("Year", "Month", "Net income", "Operating expenses", "Results"))
    
  })
  
  # #
  # observeEvent(filtered_oshtrain(),
  #              {
  #                renderBarChart(div_id = "oshtrain", direction = "vertical", grid_left = '1%', stack_plot =TRUE,show.legend = FALSE,
  #                               data = filtered_oshtrain())
  #              })
  
  #
  observeEvent(filt_income(),
               {
                 
                 # renderBarChart(div_id = "inc2", grid_left = '1%', direction = "horizontal",bar.max.width = 20,
                 #                data = filt_income())
                 renderBarChart(div_id = "inc2", grid_left = '1%', theme = "macarons",
                                direction = "vertical",
                                grid_right ="5%", grid_top="20%", grid_bottom="4%",
                                show.legend = FALSE, show.tools = TRUE,
                                font.size.legend = 12,
                                font.size.axis.x = 12, font.size.axis.y = 12,
                                axis.x.name = NULL, axis.y.name = "KES(M)",
                                rotate.axis.x = 0, rotate.axis.y = 0,
                                
                                bar.max.width = 30,
                                animation = TRUE,
                                hyperlinks = NULL,
                                
                                data = filt_income())
               })
  # 
  turnover3<- reactive({
    turnover4 %>%
      as.data.frame() %>%
      filter(Period == input$Yearfin) %>%
      set_colnames(c("Period", "variable","Turnover")) %>%
      column_to_rownames(var = "variable")%>%
      dplyr::select(Turnover)
  })
  
  observeEvent(turnover3(),
               {
                 
                 renderLineChart(div_id = "turnover", show.legend = FALSE,
                                 axis.x.name = NULL, axis.y.name = "KES(M)",
                                 
                                 data = turnover3())
               })
  
  
  
  
  
}



shiny::shinyApp(ui, server)