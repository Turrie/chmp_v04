require(plotly)
library(dplyr)
#library(flexdashboard)
library(ggplot2)
library(readxl)
library(tidyverse)


#setwd("C:/Users/User/Documents/CHMP/chmp_V02")
freq_margin=read_excel("data/sales_data.xlsx",sheet = "partner_margin")
destination=read_excel("data/sales_data.xlsx",sheet = "destination")
category=read_excel("data/sales_data.xlsx",sheet = "category")
singlebad=read_excel("data/sales_data.xlsx",sheet = "singlebad")
orders=read_excel("data/sales_data.xlsx",sheet = "margins_1")

tezt2 <- reshape2::melt(freq_margin, id=names(freq_margin)[1:2])
dest <- reshape2::melt(destination, id=names(destination)[1:2])
categ <- reshape2::melt(category, id=names(category)[1:2])
orders1 <- reshape2::melt(orders, id=names(orders)[1:2])

dest_partner=read_excel("data/actual_data/Sales_report 2019.xlsx",sheet = "3.Destinations per partner")

#destination_partner
destination1=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "Single_Destinations_1")
colnames(destination1) <- c("name", "Year", "value")

pievalues1=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "pievalues")
pievalues2 <- reshape2::melt(pievalues1, id=variable.names(pievalues1[1]))
colnames(pievalues2) <- c("Year","name",  "value")
pievalues2$value <- as.numeric(pievalues2$value)
#pievalues3 <- pievalues3%>%spread(Country, value)

destination2=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "Single_Destinations_2")
str(destination2)
destination3 <- reshape2::melt(destination2, id=names(destination2)[1])
destination3$value <- as.numeric(destination3$value)
destination4 <- destination3%>%spread(Country, value)

#conversion rates
convrates=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "Conversion Rates")
colnames(convrates) <- c("Month", "Year", "Requested","Invoiced", "Conversion_rate")

convrates$Month <- as.character(convrates$Month)
convrates$Year <- as.character(convrates$Year)

convrates$Month2 <- ifelse(convrates$Month == "January", 1,
                           ifelse(convrates$Month == "February", 2,
                                  ifelse(convrates$Month == "March", 3,
                                         ifelse(convrates$Month == "April", 4,
                                                ifelse(convrates$Month == "May", 5,
                                                       ifelse(convrates$Month == "June", 6,
                                                              ifelse(convrates$Month == "July", 7,
                                                                     ifelse(convrates$Month == "August", 8,
                                                                            ifelse(convrates$Month == "September", 9,
                                                                                   ifelse(convrates$Month == "October", 10,
                                                                                          ifelse(convrates$Month == "November", 11,
                                                                                                 12)))))))))))

convrates$Month3 <- paste(month.abb[as.numeric(convrates$Month2)], convrates$Year, sep="-" )

convrates$Conversion_rate2 <- round(convrates$Conversion_rate*100, digits = 0)
convrates$Conversion_rate3 <- paste(convrates$Conversion_rate2, "%", sep="")

#salesvsrequests


#annual turnover
annualturnover=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "Annual_Turnover")
annualturnover2 <- reshape2::melt(annualturnover, id=names(annualturnover[1]))
annualturnover2$value <- as.numeric(annualturnover2$value)
annualturnover3 <- spread(annualturnover2, variable, value)

#TO by year
tobyyear=read_excel("data/actual_data/CHMP_Sales_040121.xlsx",sheet = "Tobyyear")
tobyyear2 <- reshape2::melt(tobyyear)
#tobyyear2$variable <- as.numeric(tobyyear2$variable)
tobyyear2$value <- as.numeric(tobyyear2$value)

#procurement data
monthlyrep=read_excel("data/actual_data/PROCUREMENT REPORT 2020.xlsx",sheet = "MONTHLY REPORTS", .name_repair = "universal")
colnames(monthlyrep) <- as.character(unlist(monthlyrep[1,]))
monthlyrep2 = monthlyrep[-1, ]

colnames(monthlyrep2)<- c( "Year",  "MONTH", "BADBOYSVALUE", "PURCHASES_VALUE", "ITEMSPROCURED", "BACKORDERS", "RETURNTOSUP", "STOCKVALUE", "SAVINGSVALUE")
monthlyrep2$BADBOYSVALUE <- as.numeric(monthlyrep2$BADBOYSVALUE)
monthlyrep2$BAD_BOYS <-  round(monthlyrep2$BADBOYSVALUE/1e6,digits = 2) 
#convrates$Conversion_rate2 <- round(convrates$Conversion_rate*100, digits = 0)
monthlyrep2$PURCHASES_VALUE <- as.numeric(monthlyrep2$PURCHASES_VALUE)
monthlyrep2$PURCHASES<-  round(monthlyrep2$PURCHASES_VALUE/1e6,digits = 2) 
monthlyrep2$ITEMSPROCURED <- as.numeric(monthlyrep2$ITEMSPROCURED)
monthlyrep2$ITEMS_PROCURED <-  round(monthlyrep2$ITEMSPROCURED/1e3,digits = 2) 
monthlyrep2$BACKORDERS <- as.numeric(monthlyrep2$BACKORDERS)
monthlyrep2$BACK_ORDERS <-  round(monthlyrep2$BACKORDERS/1e6,digits = 2) 
# income4$Operating2 <-  income4$`Operating Expenses`/1e6
# income5 <- subset(monthlyrep2, select = -c(`Net Income`, `Operating Expenses`))



monthlyrep2$RETURNTOSUP <- as.numeric(monthlyrep2$RETURNTOSUP)
monthlyrep2$SUP_RETURNS <-  round(monthlyrep2$RETURNTOSUP/1e3,digits = 2) 
monthlyrep2$STOCKVALUE <- as.numeric(monthlyrep2$STOCKVALUE)
monthlyrep2$STOCK_VALUE <-  round(monthlyrep2$STOCKVALUE/1e6,digits = 2) 
monthlyrep2$SAVINGSVALUE <- as.numeric(monthlyrep2$SAVINGSVALUE)
monthlyrep2$SAVINGS <-  round(monthlyrep2$SAVINGSVALUE/1e3,digits = 2) 

monthlyrep3 <- droplevels(monthlyrep2[monthlyrep2$MONTH != "TOTAL", ])

totals <- droplevels(monthlyrep2[monthlyrep2$MONTH == "TOTAL", ])

donations=read_excel("data/actual_data/PROCUREMENT REPORT 2020.xlsx",sheet = "DONATIONS", .name_repair = "universal")
colnames(donations) <- as.character(unlist(donations[2,]))
donations2 = donations[-1, ]
donations3 = donations2[-1, ]
donations4 <- subset(donations3, select =c("Year",  "ORGANIZATION",  "VALUE", "DATE"))
donations4$VALUE <- as.numeric(donations4$VALUE)

catpro=read_excel("data/procurement data.xlsx",sheet = "category")
catsup=read_excel("data/procurement data.xlsx",sheet = "supplier")
singlepro=read_excel("data/procurement data.xlsx",sheet = "single")
itemlist=read_excel("data/procurement data.xlsx",sheet = "itemlist")
catpro2 <- reshape2::melt(catpro, id=names(catpro)[1:2])
catsup2 <- reshape2::melt(catsup, id=names(catsup)[1:2])
itemlist2 <- reshape2::melt(itemlist, id=names(itemlist)[1:2])

###HR data####
leave19=read_excel("data/actual_data/LEAVE SCHEDULE DEC'2020.xlsx",sheet = "2019")
leave20=read_excel("data/actual_data/LEAVE SCHEDULE DEC'2020.xlsx",sheet = "2020")

#ADMIN-uncomment NEXT LINES when new year is added
#leave21=read_excel("data/LEAVE SCHEDULE DEC'2020.xlsx",sheet = "2021")
#leave22=read_excel("data/LEAVE SCHEDULE DEC'2020.xlsx",sheet = "2022")


hrleave=read_excel("data/actual_data/HR.xlsx",sheet = "leave")
hrtest=read_excel("data/hrtest.xlsx",sheet = "Sheet1", .name_repair = "universal")

#leave information
leaveinfo=read_excel("data/actual_data/HR.xlsx",sheet = "leaveinfo", .name_repair = "universal")
colnames(leaveinfo) <- as.character(unlist(leaveinfo[2,]))
leaveinfo2 = leaveinfo[-1, ]
leaveinfo3 = leaveinfo2[-1, ]
leaveinfo4 <- subset(leaveinfo3, select = c("Year", "NAME_OF_EMPLOYEE", "Q1","Q2","Q3","Q4"))
leaveinfo4b <- leaveinfo4
colnames(leaveinfo4b) <- c("Year", "NAME_OF_EMPLOYEE", "Q1","Q2","Q3","Q4")
leaveinfo5 <- reshape2::melt(leaveinfo4b, id=names(leaveinfo4b)[1:2])
leaveinfo6 <- spread(leaveinfo5,NAME_OF_EMPLOYEE, value )

#No. of staff that took leave
staff_leave <- leaveinfo4
staff_leave$Quarter1 <- ifelse(staff_leave$Q1 == 0,  "didn't take leave", "took leave")
staff_leave$Quarter2 <- ifelse(staff_leave$Q2 == 0, "didn't take leave", "took leave")
staff_leave$Quarter3 <- ifelse(staff_leave$Q3 == 0, "didn't take leave", "took leave")
staff_leave$Quarter4 <- ifelse(staff_leave$Q4 == 0, "didn't take leave", "took leave")
staff_leave$Q1 <- as.numeric(staff_leave$Q1)
staff_leave$Q2 <- as.numeric(staff_leave$Q2)
staff_leave$Q3 <- as.numeric(staff_leave$Q3)
staff_leave$Q4 <- as.numeric(staff_leave$Q4)

staff_leave2 <- reshape2::melt(staff_leave, id=names(staff_leave)[1:6])
staff_leave2$variable2 <- ifelse(staff_leave2$variable == "Quarter1", "Q1",
                                ifelse(staff_leave2$variable == "Quarter2", "Q2",
                                       ifelse(staff_leave2$variable == "Quarter3", "Q3",
                                              "Q4")))


#staff data
staff_data=read_excel("data/actual_data/HR.xlsx",sheet = "STAFF", .name_repair = "universal")
colnames(staff_data) <- c("Year",  "Name", "Gender","Status","Department","Disciplinary_action")
staff_data2 <- subset(staff_data, select = c("Year",  "Name", "Gender","Status","Department","Disciplinary_action"))
staff_data2$Department2 <- ifelse(staff_data2$Department == "HR&ADMIN", "HR and Admin",
                                  ifelse(staff_data2$Department == "IT\\OSH", "IT or OSH",
                                         ifelse(staff_data2$Department == "WAREHOUSE & DISTRIBUTION", "WAREHOUSE and DISTRIBUTION",
                                                as.character(staff_data2$Department))))
staff_data2$Disciplinary_action2 <- ifelse(is.na(staff_data2$Disciplinary_action), "No", "Yes")


library(tidyverse)

#hrdata=read_excel("data/HR.xlsx",sheet = "HR")
hrstf=read_excel("data/actual_data/HR.xlsx",sheet = "staff_full")
singlehr=read_excel("data/actual_data/HR.xlsx",sheet = "single")
hrstf <- as.data.frame(hrstf)
hrstf2 <- reshape2::melt(hrstf, id=names(hrstf)[1:2])

gender=read_excel("data/actual_data/HR.xlsx",sheet = "gender")

training=read_excel("data/actual_data/HR.xlsx",sheet = "training")
training2 <- reshape2::melt(training, id=names(training)[1:2])

####OSHdata
audits =read_excel("data/actual_data/OSH.xlsx",sheet = "audit2") 
injury =read_excel("data/actual_data/OSH.xlsx",sheet = "injury")
injury2 <- reshape2::melt(injury, id=names(injury)[1:3])
risks =read_excel("data/actual_data/OSH.xlsx",sheet = "risks")
oshtrain =read_excel("data/actual_data/OSH.xlsx",sheet = "training")

###warehouse data
num_supplies=read_excel("data/actual_data/WAREHOUSE AND DISTRIBUTION MONTHLY REPORT 2019.xlsx",sheet = "WD Receiving")
colnames(num_supplies) <- as.character(unlist(num_supplies[2,]))
num_supplies2 = num_supplies[-1, ]
num_supplies3 = num_supplies2[-1, ]
colnames(num_supplies3) <- c("Year",  "Month", "No_of_suppliers","Items_Received","Quantity_Received","Average_supplier_delivery")
num_supplies3$No_of_suppliers <- as.numeric(num_supplies3$No_of_suppliers)
num_supplies3$Items_Received <- as.numeric(num_supplies3$Items_Received)
num_supplies3$Quantity_Received <- as.numeric(num_supplies3$Quantity_Received)
num_supplies3$Average_supplier_delivery <- as.numeric(num_supplies3$Average_supplier_delivery)
num_supplies4 <- subset(num_supplies3, select = c("Year", "Month", "No_of_suppliers", "Items_Received", "Average_supplier_delivery", "Quantity_Received"))

order_prep=read_excel("data/actual_data/WAREHOUSE AND DISTRIBUTION MONTHLY REPORT 2019.xlsx",sheet = "WD Order Preparation")
colnames(order_prep) <- as.character(unlist(order_prep[2,]))
order_prep2 = order_prep[-1, ]
order_prep3 = order_prep2[-1, ]
colnames(order_prep3) <- c("Year",  "Month", "No_of_orders","Weight","Volume_m3","avgtime_order", "unit")
order_prep3$No_of_orders <- as.numeric(order_prep3$No_of_orders)
order_prep3$Weight <- as.numeric(order_prep3$Weight)
order_prep3$Volume_m3 <- as.numeric(order_prep3$Volume_m3)
order_prep3$avgtime_order <- as.numeric(order_prep3$avgtime_order)
order_prep4 <- subset(order_prep3, select = c("Year",  "Month", "No_of_orders","Weight","Volume_m3","avgtime_order", "unit"))


equipment=read_excel("data/actual_data/WAREHOUSE AND DISTRIBUTION MONTHLY REPORT 2019.xlsx",sheet = "WD Equipment services")
colnames(equipment) <- as.character(unlist(equipment[2,]))
equipment2 = equipment[-1, ]
equipment3 = equipment2[-1, ]
colnames(equipment3) <- c("Year",  "Month", "KCR_497T","Cost1","KBX_077K","Cost2", "Cold_room", "Cost3", "Generator_Service","Scales_Calibration",
                          "Stacker","Pallet_pusher", "Costofmaintenance")

equipment3$Costofmaintenance <- as.numeric(equipment3$Costofmaintenance)

equipment4 <- subset(equipment3, select = c("Year",  "Month", "Costofmaintenance"))


items =read_excel("data/warehouse.xlsx",sheet = "items")
items2 <- reshape2::melt(items, id=names(items)[1:4])
category =read_excel("data/warehouse.xlsx",sheet = "category")
singular =read_excel("data/warehouse.xlsx",sheet = "singular")
ware =read_excel("data/warehouse.xlsx",sheet = "ware")
ware2 <- reshape2::melt(ware, id=names(ware)[1:3])

planned =read_excel("data/quality_assurance.xlsx",sheet = "testplan")
planned2 <- reshape2::melt(planned, id=names(planned)[1:3])
singleqa =read_excel("data/quality_assurance.xlsx",sheet = "singleqa")
intext =read_excel("data/quality_assurance.xlsx",sheet = "intext")
intext2 <- reshape2::melt(intext, id=names(intext)[1:3])

##it data
singleit =read_excel("data/actual_data/IT Data M&E2.xlsx",sheet = "single")
utrain =read_excel("data/actual_data/IT Data M&E2.xlsx",sheet = "usertraining")
utrain2 <- reshape2::melt(utrain, id=names(utrain)[1:2])
utrain3 <- utrain2%>%spread(training, value)
utrain3$`New users' training` <- as.numeric(utrain3$`New users' training`)
utrain3$`Refresher training` <- as.numeric(utrain3$`Refresher training`)

usertraining <- reshape2::melt(utrain, id=names(utrain)[1:2])
consumables1 =read_excel("data/actual_data/IT Data M&E2.xlsx",sheet = "Consumables")
issues =read_excel("data/actual_data/IT Data M&E2.xlsx",sheet = "issues")

#Finance
income =read_excel("data/actual_data/Monthly Financials 2020.xlsx", sheet="Graph - Income & Expenditure")
income2 <- income%>%gather(Month, value, Jan, Feb,   March ,April ,May, June,   
                           July,  August, September, October,November,December, factor_key = TRUE)
income3 <- income2%>%spread(item, value)
income4 <- subset(income3, select = -c(Results))

income4$Net2 <-  round(income4$`Net Income`/1e6,digits = 2) 
income4$Operating2 <-  round(income4$`Operating Expenses`/1e6,digits = 2) 
income5 <- subset(income4, select = -c(`Net Income`, `Operating Expenses`))

#income2 <- reshape2::melt(income, id=names(income)[1:2])

singlefin =read_excel("data/actual_data/Monthly Financials 2020.xlsx", sheet="single")
singlefin2 =read_excel("data/actual_data/Monthly Financials 2020.xlsx", sheet="fin")
turnover =read_excel("data/actual_data/Monthly Financials 2020.xlsx", sheet="Graph - Turnover")
turnover2 <- reshape2::melt(turnover, id=names(turnover)[1])
# df <- data.frame(x = c(0, 200,100),
#                  y = c(7500000,10000000,2000000)) %>% 
#   mutate(y_millions = y/1e6)
turnover2$value2 <-  round(turnover2$value/1e6,digits = 2) 
turnover4 <- subset(turnover2, select = -c(value))

#QA##################################################################
#gmpaudits
gmpaudits =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single1", .name_repair = "universal")
colnames(gmpaudits) <- as.character(unlist(gmpaudits[2,]))
gmpaudits2 = gmpaudits[-1, ]
gmpaudits3 = gmpaudits2[-1, ]

#MQAS, GSP & GDP AUDITS 2019
mqas =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single2", .name_repair = "universal")
colnames(mqas) <- as.character(unlist(mqas[2,]))
mqas2 = mqas[-1, ]
mqas3 = mqas2[-1, ]

#glpaudits
glpaudits =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single3", .name_repair = "universal")
colnames(glpaudits) <- as.character(unlist(glpaudits[2,]))
glpaudits2 = glpaudits[-1, ]
glpaudits3 = glpaudits2[-1, ]
colnames(glpaudits3) <- c("Year", "Month", "Total")
glpaudits3$Total <- as.numeric(glpaudits3$Total)
glpaudits3[is.na(glpaudits3)] <- 0


#partner complaints
partcompl =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="partcompl", .name_repair = "universal")
colnames(partcompl) <- as.character(unlist(partcompl[2,]))
partcompl2 = partcompl[-1, ]
partcompl3 = partcompl2[-1, ]

#supplier complaints
supcompl =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="supcompl", .name_repair = "universal")
colnames(supcompl) <- as.character(unlist(supcompl[2,]))
supcompl2 = supcompl[-1, ]
supcompl3 = supcompl2[-1, ]
supcompl3$January <- as.numeric(supcompl3$January)
supcompl3$February <- as.numeric(supcompl3$February)
supcompl3$March <- as.numeric(supcompl3$March)
supcompl3$April <- as.numeric(supcompl3$April)
supcompl3$May <- as.numeric(supcompl3$May)
supcompl3$June <- as.numeric(supcompl3$June)
supcompl3$July <- as.numeric(supcompl3$July)# supcompl4 <- reshape2::melt(supcompl3, id=names(supcompl3)[1:5])
supcompl3$August <- as.numeric(supcompl3$August)
supcompl3$September <- as.numeric(supcompl3$September)
supcompl3$October <- as.numeric(supcompl3$October)
# supcompl3$November <- as.numeric(supcompl3$November)
# supcompl3$December <- as.numeric(supcompl3$December)
supcompl3[is.na(supcompl3)] <- 0


# supcompl5 <- supcompl4[!is.na(supcompl4$value), ]



#supplier inc/dec
supinc =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="supinc", .name_repair = "universal")
colnames(supinc) <- as.character(unlist(supinc[2,]))
supinc2 = supinc[-1, ]
supinc3 = supinc2[-1, ]

#iintaudit
intaudit =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="INTAUDIT", .name_repair = "universal")
colnames(intaudit) <- as.character(unlist(intaudit[2,]))
intaudit2 = intaudit[-1, ]
intaudit3 = intaudit2[-1, ]
intaudit3$Completed  <- as.numeric(intaudit3$Completed )
intaudit3$Pending <- as.numeric(intaudit3$Pending)
intaudit3[is.na(intaudit3)] <- 0
intaudit3$status <- ifelse(intaudit3$Completed == 1, "Completed", "Pending")

#number of items
items =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single7", .name_repair = "universal")
colnames(items) <- as.character(unlist(items[2,]))
items2 = items[-1, ]
colnames(items2) <- c("Items", "Total")

#qc schedule
qc_schedule =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="INSPE", .name_repair = "universal")
colnames(qc_schedule) <- as.character(unlist(qc_schedule[2,]))
qc_schedule2 = qc_schedule[-1, ]
qc_schedule3 = qc_schedule2[-1, ]
colnames(qc_schedule3) <- c("Year", "Completed", "Pending", "Total")

#extaudit
extaudit =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="EXTAUDIT", .name_repair = "universal")
colnames(extaudit) <- as.character(unlist(extaudit[2,]))
extaudit2 = extaudit[-1, ]
extaudit3 = extaudit2[-1, ]
extaudit4 <- reshape2::melt(extaudit3, id=names(extaudit3)[1])
extaudit4$value <- as.numeric(extaudit4$value)
extaudit4[is.na(extaudit4)] <- 0
colnames(extaudit4) <- c("Auditee_process", "Completed", "value")
extaudit4$Completed2 <- ifelse(extaudit4$Completed == "Underprocess", "Under process", 
                               
                               ifelse(extaudit4$Completed == "Underprocess\r\n(Status of CAPA unknown)", "Status of CAPA unknown", 
                                      as.character(extaudit4$Completed)))
extaudit4b <- droplevels(extaudit4[extaudit4$value == 1, ])
extaudit5 <- droplevels(extaudit4b[!extaudit4b$Completed2 == "Grand Total", ])

extaudit5$carb <- ifelse(extaudit5$Completed2 == "Completed", 1,
                         ifelse(extaudit5$Completed2 == "Under process", 2,
                                ifelse(extaudit5$Completed2 == "Continous", 3,
                                       ifelse(extaudit5$Completed2 == "Not applicable", 4,
                                              ifelse(extaudit5$Completed2 == "Status of CAPA unknown", 5,
                                                     as.character(extaudit5$Completed2))))))

extaudit6 <- subset(extaudit5, select = c(Auditee_process, Completed2))

#non conformities

conform =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single11", .name_repair = "universal")
colnames(conform) <- as.character(unlist(conform[2,]))
conform2 = conform[-1, ]
conform3 = conform2[-1, ]
colnames(conform3) <- c("Year","Source", "Nature", "closed", "new")

conform3$closed <- as.numeric(conform3$closed)
conform3$new <- as.numeric(conform3$new)
conform3[is.na(conform3)]<- 0
conform4 <- reshape2::melt(conform3, id=names(conform3)[1:3])
conform4$cat <- paste(conform3$Nature, conform3$closed, sep = "")

breakdown =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single11b", .name_repair = "universal")
colnames(breakdown) <- as.character(unlist(breakdown[2,]))
breakdown2 = breakdown[-1, ]
breakdown3 = breakdown2[-1, ]
colnames(breakdown3)<- c("Year", "Critical", "Major", "minor", "drop")
breakdown4 <- subset(breakdown3, select = -c(drop))
breakdown4$Critical  <- as.numeric(breakdown4$Critical)
breakdown4$Major   <- as.numeric(breakdown4$Major)
breakdown4$minor  <- as.numeric(breakdown4$minor)
breakdown4[is.na(breakdown4)]<- 0


#risk analysis
riskcat =read_excel("data/actual_data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="single13", .name_repair = "universal")
colnames(riskcat) <- as.character(unlist(riskcat[1,]))
riskcat2 = riskcat[-1, ]
colnames(riskcat2) <- c("Year", "Risk", "Month", "infrastructure_assetmanagement", "performance_financial", "Productandservicedelivery")
riskcat2$infrastructure_assetmanagement <- as.numeric(riskcat2$infrastructure_assetmanagement)
riskcat2$performance_financial <- as.numeric(riskcat2$performance_financial)
riskcat2$Productandservicedelivery <- as.numeric(riskcat2$Productandservicedelivery)
riskcat2[is.na(riskcat2)]<- 0

# conform5 <- spread(conform4, cat, value)
# conform6 <- subset(conform5, select=-c(Nature, variable))
# # server <- function(input,output) {
#   output$p <- renderPlot(ggplot(extaudit5,aes(x=factor(carb),y=value))+
#                            geom_bar(stat="summary",fun.y="mean"))
#   output$info <- renderText(
#     paste0("x=", input$plot_click$x, "\n",
#            "y=", input$plot_click$y))
# 
#   output$table <- renderTable({
#     ##magic happens here##
#     output$table <- renderTable({
#       carb <- unique(extaudit5$carb)
#       carb <- carb[order(carb)]
#       x <- carb[round(input$plot_click$x)]
#       extaudit5[extaudit5$carb == x,]
#     })
# 
#   })
# }
# shinyApp(ui, server)

# #internal audits status
# intaudit =read_excel("data/QA DEPT  2020 ACTIVITY REPORT.xlsx", sheet="INTAUDIT", .name_repair = "universal")
# colnames(supinc) <- as.character(unlist(supinc[2,]))
# supinc2 = supinc[-1, ]
# supinc3 = supinc2[-1, ]

# QA5 <- subset(QA5, select = c("Year", "Month", `Grand Total`, .name_repair = "universal"))
# 
# QAs3 =read_excel("data/qadept.xlsx", sheet="Sheet1")
# colnames(QA3) <- as.character(unlist(QA3[2,]))
# QA4 = QA3[-1, ]
# QA5 = QA4[-1, ]
# QA5 <- subset(QA5, select = c("Year", "Month", `Grand Total`, .name_repair = "universal"))